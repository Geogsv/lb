from flask import Flask, render_template, request, redirect, url_for, session
from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneNumberInvalidError, ApiIdInvalidError, ApiIdPublishedFloodError
import asyncio
import os

app = Flask(__name__) # app создается здесь

# Чтение секретного ключа из переменной окружения. ОБЯЗАТЕЛЬНО УСТАНОВИТЕ ЕЕ!
app.secret_key = os.environ.get('FLASK_APP_SECRET_KEY', 'fallback-default-secret-key-CHANGE-THIS') # Для локального запуска или если переменная не задана
if app.secret_key == 'fallback-default-secret-key-CHANGE-THIS' and not app.debug:
    print("ПРЕДУПРЕЖДЕНИЕ: Используется небезопасный FLASK_APP_SECRET_KEY по умолчанию в продакшене!")


# --- КОНФИГУРАЦИЯ ---
# SESSION_NAME используется для проверки наличия старых файловых сессий на главной.
SESSION_NAME = "my_telegram_session" 
# --------------------


@app.route('/')
def index():
    # Очищаем сессию Flask от данных предыдущих попыток
    for key in ['api_id', 'api_hash', 'phone_number', 'phone_code_hash', 
                'needs_password_now', 'current_code_value_on_error', 
                'telethon_string_session_intermediate']:
        session.pop(key, None)
    
    session_file_exists = os.path.exists(f"{SESSION_NAME}.session") # Проверяем в текущей рабочей директории контейнера
    return render_template('index.html', session_file_exists=session_file_exists, session_filename=f"{SESSION_NAME}.session")

@app.route('/submit_credentials', methods=['POST'])
def submit_credentials():
    api_id_str = request.form.get('api_id')
    api_hash = request.form.get('api_hash')
    phone_number = request.form.get('phone_number')

    if not all([api_id_str, api_hash, phone_number]):
        return render_template('index.html', error="Все поля (API ID, API Hash, Номер телефона) обязательны.")

    try:
        api_id = int(api_id_str)
    except ValueError:
        return render_template('index.html', error="API ID должен быть числом.")

    session['api_id'] = api_id
    session['api_hash'] = api_hash
    session['phone_number'] = phone_number
    session.pop('needs_password_now', None)
    session.pop('current_code_value_on_error', None)
    session.pop('telethon_string_session_intermediate', None)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    client = None
    
    current_string_session_obj = StringSession()

    try:
        client = TelegramClient(current_string_session_obj, api_id, api_hash, loop=loop, system_version="4.16.30-vxCUSTOM")
        client.connect()
        if not client.is_connected():
            return render_template('error.html', message="Не удалось подключиться к Telegram.")

        sent_code = client.send_code_request(phone_number)
        session['phone_code_hash'] = sent_code.phone_code_hash
        session['telethon_string_session_intermediate'] = current_string_session_obj.save()
        
        return redirect(url_for('enter_code'))

    except (ApiIdInvalidError, ApiIdPublishedFloodError):
        return render_template('index.html', error="Неверный API ID или API Hash.")
    except PhoneNumberInvalidError:
        return render_template('index.html', error="Неверный формат номера телефона. Укажите в международном формате (например, +79001234567).")
    except ConnectionError as e:
         return render_template('error.html', message=f"Ошибка подключения к Telegram: {e}. Проверьте интернет-соединение или доступность серверов Telegram.")
    except Exception as e:
        app.logger.error(f"Ошибка при отправке кода: {e}", exc_info=True)
        return render_template('error.html', message=f"Произошла непредвиденная ошибка: {e}")
    finally:
        if client and client.is_connected():
            client.disconnect()
        if loop and not loop.is_closed():
            loop.close()

@app.route('/enter_code', methods=['GET', 'POST'])
def enter_code():
    api_id = session.get('api_id')
    api_hash = session.get('api_hash')
    phone_number = session.get('phone_number')
    
    needs_password_now = session.get('needs_password_now', False)
    current_code_value_on_error = session.get('current_code_value_on_error', '') 
    
    saved_intermediate_session_str = session.get('telethon_string_session_intermediate')

    if not all([api_id, api_hash, phone_number]):
        return redirect(url_for('index'))
    
    if not saved_intermediate_session_str and not needs_password_now:
        app.logger.warning("Промежуточная строка сессии не найдена в enter_code, перенаправляем на главную.")
        return redirect(url_for('index'))

    current_string_session_obj = StringSession(saved_intermediate_session_str)

    if request.method == 'GET':
        code_to_display_if_needed = current_code_value_on_error if not needs_password_now else ''
        return render_template('enter_code.html', 
                               code_value=code_to_display_if_needed, 
                               needs_password=needs_password_now)

    # POST-запрос
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    client = None

    try:
        client = TelegramClient(current_string_session_obj, api_id, api_hash, loop=loop, system_version="4.16.30-vxCUSTOM")
        client.connect()
        if not client.is_connected():
            return render_template('error.html', message="Не удалось подключиться к Telegram для ввода кода/пароля.")

        if needs_password_now: 
            password = request.form.get('password')
            if not password:
                return render_template('enter_code.html', 
                                       error="Пароль 2FA обязателен.", 
                                       code_value='', 
                                       needs_password=True)
            
            client.sign_in(password=password)
        
        else: 
            code_from_form = request.form.get('code')
            phone_code_hash = session.get('phone_code_hash') 
            session['current_code_value_on_error'] = code_from_form

            if not code_from_form:
                return render_template('enter_code.html', error="Код подтверждения обязателен.", code_value=code_from_form, needs_password=False)
            if not phone_code_hash:
                 app.logger.error("phone_code_hash отсутствует в сессии на этапе ввода кода.")
                 return redirect(url_for('index'))

            client.sign_in(phone=phone_number, code=code_from_form, phone_code_hash=phone_code_hash)
            
        final_session_string = client.session.save() 

        for key in ['api_id', 'api_hash', 'phone_number', 'phone_code_hash', 
                    'current_code_value_on_error', 'needs_password_now', 
                    'telethon_string_session_intermediate']:
            session.pop(key, None)
        
        return render_template('success.html', 
                               message="Авторизация прошла успешно! Ваша сессионная строка Telethon готова:", 
                               session_string_to_display=final_session_string)

    except SessionPasswordNeededError:
        session['needs_password_now'] = True
        session['telethon_string_session_intermediate'] = current_string_session_obj.save()
        session.pop('current_code_value_on_error', None) 
        
        return render_template('enter_code.html', 
                               error="Требуется пароль двухфакторной аутентификации (2FA). Код был принят.", 
                               code_value='', 
                               needs_password=True)
    
    except PhoneCodeInvalidError:
        session.pop('needs_password_now', None) 
        return render_template('enter_code.html', 
                               error="Введен неверный код подтверждения.", 
                               code_value=session.get('current_code_value_on_error', ''), 
                               needs_password=False)
    
    except Exception as e:
        app.logger.error(f"Ошибка при вводе кода/пароля: {e}", exc_info=True)
        error_message = f"Произошла ошибка: {e}"
        is_password_stage_on_error = session.get('needs_password_now', False)
        code_val_on_error = '' if is_password_stage_on_error else session.get('current_code_value_on_error', '')
        return render_template('enter_code.html', error=error_message, code_value=code_val_on_error, needs_password=is_password_stage_on_error)
    
    finally:
        if client and client.is_connected():
            client.disconnect()
        if loop and not loop.is_closed():
            loop.close()

# Этот блок будет использоваться только если вы запускаете `python app/app.py` локально для теста,
# Gunicorn будет импортировать `app` объект напрямую.
if __name__ == '__main__':
    # Для локальной разработки можно оставить debug=True, но Gunicorn его переопределит
    app.run(debug=True, host='0.0.0.0', port=5000)