import logging
import os
import asyncio

from dotenv import load_dotenv
# Импорты Telethon
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import (
    SessionPasswordNeededError, FloodWaitError, PhoneCodeInvalidError,
    PhoneNumberInvalidError, PhoneCodeExpiredError, ApiIdInvalidError
)
# Импорты PTB
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler
)
from telegram.constants import ParseMode

# --- Загрузка переменных окружения ---
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(dotenv_path): load_dotenv(dotenv_path); print("Загружен .env для session_generator_bot")
else: print("Предупреждение: .env для session_generator_bot не найден.")

SESSION_BOT_TOKEN = os.getenv('SESSION_BOT_TOKEN')
ADMIN_USER_IDS_STR = os.getenv('SESSION_ADMIN_USER_IDS')
LOG_LEVEL_STR = os.getenv('LOG_LEVEL', 'INFO').upper()

if not SESSION_BOT_TOKEN: exit("Критическая ошибка: SESSION_BOT_TOKEN не установлен.")
if not ADMIN_USER_IDS_STR: exit("Критическая ошибка: SESSION_ADMIN_USER_IDS не установлен.")

try:
    ADMIN_USER_IDS = [int(admin_id.strip()) for admin_id in ADMIN_USER_IDS_STR.split(',')]
except ValueError: exit(f"Критическая ошибка: SESSION_ADMIN_USER_IDS ({ADMIN_USER_IDS_STR}) содержит нечисловое значение.")

# --- Настройка логирования ---
numeric_log_level = getattr(logging, LOG_LEVEL_STR, logging.INFO)
logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] SessionGenBot: %(message)s', level=numeric_log_level)
logger = logging.getLogger(__name__)
logger.info(f"Уровень логирования бота-генератора: {LOG_LEVEL_STR}")

# --- Состояния для ConversationHandler ---
(ASK_API_ID, ASK_API_HASH, ASK_PHONE, ASK_CODE, ASK_PASSWORD) = map(chr, range(5))

# --- Декоратор для проверки прав администратора ---
# (Такой же, как в admin_bot.py, но проверяет SESSION_ADMIN_USER_IDS)
def restricted(func):
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        if user_id not in ADMIN_USER_IDS:
            logger.warning(f"Неавторизованный доступ от user_id: {user_id}")
            await update.message.reply_text("У вас нет прав использовать этого бота.")
            return ConversationHandler.END # Завершаем диалог, если нет прав
        return await func(update, context, *args, **kwargs)
    # Добавляем атрибут, чтобы ConversationHandler мог его отличить от обычного MessageHandler
    wrapped._is_restricted = True 
    return wrapped

# --- Функции диалога ---
@restricted
async def start_session_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Начинает диалог генерации сессии."""
    logger.info(f"Запрос на генерацию сессии от {update.effective_user.id}")
    await update.message.reply_text(
        "Привет! Я помогу тебе получить строку сессии Telethon.\n"
        "Пожалуйста, подготовь API ID и API Hash с my.telegram.org.\n\n"
        "1. Введи **API ID** (число).\n\n"
        "Для отмены в любое время введи /cancel."
    )
    return ASK_API_ID

@restricted
async def received_api_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод API ID."""
    try:
        api_id = int(update.message.text.strip())
        if api_id <= 0: raise ValueError("API ID < 0")
        context.user_data['api_id'] = api_id
        await update.message.reply_text(f"API ID: `{api_id}`.\n2. Теперь введи **API HASH**.", parse_mode=ParseMode.MARKDOWN)
        return ASK_API_HASH
    except ValueError:
        await update.message.reply_text("API ID должен быть целым положительным числом. Попробуй еще раз или /cancel.")
        return ASK_API_ID

@restricted
async def received_api_hash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод API Hash и проверяет их валидность."""
    api_hash = update.message.text.strip()
    if not api_hash or len(api_hash) < 30 or not all(c in '0123456789abcdefABCDEF' for c in api_hash):
        await update.message.reply_text("API HASH невалиден (hex, ~32 символа). Еще раз или /cancel.")
        return ASK_API_HASH
    context.user_data['api_hash'] = api_hash

    api_id = context.user_data['api_id']
    # Проверка валидности через временный клиент
    temp_client = None
    try:
        logger.info(f"Проверка API ID/Hash ({api_id})...")
        temp_client = TelegramClient(StringSession(), api_id, api_hash)
        await temp_client.connect()
        logger.info("API ID/Hash валидны.")
        await temp_client.disconnect()
    except ApiIdInvalidError:
        await update.message.reply_text("Ошибка: API ID или API HASH невалидны. /start для новой попытки.")
        context.user_data.clear(); return ConversationHandler.END
    except FloodWaitError as e_flood:
         await update.message.reply_text(f"FloodWait: {e_flood.seconds} сек. Попробуй /start позже.")
         context.user_data.clear(); return ConversationHandler.END
    except Exception as e_conn:
         logger.warning(f"Ошибка при проверке API ({e_conn}).") # Продолжаем без проверки
    finally:
        if temp_client and temp_client.is_connected(): await temp_client.disconnect()

    await update.message.reply_text("API HASH получен.\n3. Введи **номер телефона** (+...).")
    return ASK_PHONE

@restricted
async def received_phone(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод номера телефона и отправляет код."""
    phone = update.message.text.strip()
    if not phone.startswith('+') or not phone[1:].isdigit() or len(phone) < 10:
        await update.message.reply_text("Неверный формат номера (+...). Еще раз или /cancel.")
        return ASK_PHONE
    context.user_data['phone'] = phone

    api_id = context.user_data['api_id']
    api_hash = context.user_data['api_hash']
    # Используем новую сессию в памяти для каждого запроса кода
    temp_client = TelegramClient(StringSession(), api_id, api_hash)
    context.user_data['temp_client'] = temp_client

    try:
        logger.info(f"Подключение клиента для кода {phone}...")
        if not temp_client.is_connected(): await temp_client.connect()
        logger.info(f"Отправка кода на {phone}...")
        sent_code = await temp_client.send_code_request(phone, force_sms=False) # force_sms можно сделать опцией
        context.user_data['phone_code_hash'] = sent_code.phone_code_hash
        logger.info(f"Код отправлен. Hash: {sent_code.phone_code_hash}")
        await update.message.reply_text("Код отправлен в Telegram (или SMS).\n4. Введи **код** (действителен недолго!).")
        return ASK_CODE
    except (FloodWaitError, PhoneNumberInvalidError) as e:
        msg = f"Ошибка Telegram: {type(e).__name__}. "
        msg += f"Ждите {e.seconds} сек." if isinstance(e, FloodWaitError) else "Проверьте номер."
        await update.message.reply_text(msg + " /start для новой попытки.")
        if temp_client.is_connected(): await temp_client.disconnect()
        context.user_data.clear(); return ConversationHandler.END
    except Exception as e:
        logger.error(f"Ошибка send_code_request: {e}", exc_info=True)
        await update.message.reply_text(f"Ошибка: {e}. /start для новой попытки.")
        if temp_client and temp_client.is_connected(): await temp_client.disconnect()
        context.user_data.clear(); return ConversationHandler.END

@restricted
async def received_code(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод кода подтверждения."""
    code = update.message.text.strip()
    if not code.isdigit(): await update.message.reply_text("Код - только цифры. Еще раз."); return ASK_CODE

    phone = context.user_data.get('phone')
    ph_hash = context.user_data.get('phone_code_hash')
    temp_client: TelegramClient = context.user_data.get('temp_client')
    if not all([phone, ph_hash, temp_client]):
        await update.message.reply_text("Ошибка контекста. /start."); return ConversationHandler.END

    try:
        logger.info(f"Вход с кодом для {phone}...")
        # Пытаемся войти с кодом
        await temp_client.sign_in(phone, code, phone_code_hash=ph_hash)
        # Успех без 2FA
        session_str = temp_client.session.save()
        logger.info(f"Успешный вход для {phone}! Session: ...{session_str[-10:]}")
        await update.message.reply_text("✅ Авторизация успешна! Ваша строка сессии Telethon:")
        # Отправляем строку сессии отдельным сообщением, чтобы ее было легко скопировать
        await update.message.reply_text(f"`{session_str}`", parse_mode=ParseMode.MARKDOWN)
        await update.message.reply_text("Скопируйте эту строку и сохраните в безопасном месте. Используйте ее при добавлении агента в основном управляющем боте.")
        if temp_client.is_connected(): await temp_client.disconnect()
        context.user_data.clear(); return ConversationHandler.END

    except SessionPasswordNeededError:
        logger.info(f"Требуется пароль 2FA для {phone}.")
        await update.message.reply_text("Требуется пароль 2FA.\n5. Введите **пароль 2FA**.")
        return ASK_PASSWORD
    except (PhoneCodeInvalidError, PhoneCodeExpiredError) as e:
        msg = "Неверный код." if isinstance(e, PhoneCodeInvalidError) else "Код истек."
        await update.message.reply_text(msg + " Попробуйте код еще раз или /cancel.")
        return ASK_CODE # Даем еще попытку
    except FloodWaitError as e:
        await update.message.reply_text(f"FloodWait: {e.seconds} сек. /start позже.")
        if temp_client.is_connected(): await temp_client.disconnect()
        context.user_data.clear(); return ConversationHandler.END
    except Exception as e:
        logger.error(f"Ошибка sign_in с кодом: {e}", exc_info=True)
        await update.message.reply_text(f"Ошибка: {e}. /start.")
        if temp_client and temp_client.is_connected(): await temp_client.disconnect()
        context.user_data.clear(); return ConversationHandler.END

@restricted
async def received_password(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод пароля 2FA."""
    password = update.message.text # Без strip()
    temp_client: TelegramClient = context.user_data.get('temp_client')
    if not temp_client:
        await update.message.reply_text("Ошибка контекста. /start."); return ConversationHandler.END
    try:
        logger.info(f"Вход с паролем 2FA...")
        await temp_client.sign_in(password=password)
        # Успех
        session_str = temp_client.session.save()
        logger.info(f"Успешный вход с 2FA! Session: ...{session_str[-10:]}")
        await update.message.reply_text("✅ Пароль принят, авторизация успешна! Ваша строка сессии Telethon:")
        await update.message.reply_text(f"`{session_str}`", parse_mode=ParseMode.MARKDOWN)
        await update.message.reply_text("Скопируйте эту строку и сохраните.")
        if temp_client.is_connected(): await temp_client.disconnect()
        context.user_data.clear(); return ConversationHandler.END
    except FloodWaitError as e:
        await update.message.reply_text(f"FloodWait: {e.seconds} сек. /start позже.")
        if temp_client.is_connected(): await temp_client.disconnect()
        context.user_data.clear(); return ConversationHandler.END
    except Exception as e: # Включая неверный пароль
        logger.error(f"Ошибка sign_in с паролем: {e}")
        await update.message.reply_text(f"Ошибка (возможно, неверный пароль): {e}. Пароль еще раз или /cancel.")
        return ASK_PASSWORD # Даем еще попытку

async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Отменяет текущий диалог генерации сессии."""
    user_id = update.effective_user.id
    logger.info(f"Пользователь {user_id} отменил генерацию сессии.")
    # Отключаем временный клиент, если он был создан
    if 'temp_client' in context.user_data:
        temp_client: TelegramClient = context.user_data['temp_client']
        if temp_client and temp_client.is_connected():
            try: await temp_client.disconnect(); logger.info("Временный клиент отключен при отмене.")
            except Exception as e_dc: logger.warning(f"Ошибка отключения клиента при отмене: {e_dc}")
    await update.message.reply_text("Генерация строки сессии отменена. Введите /start для новой попытки.")
    context.user_data.clear()
    return ConversationHandler.END

# --- Точка входа ---
def main() -> None:
    """Запускает бота-генератора сессий."""
    application = Application.builder().token(SESSION_BOT_TOKEN).build()

    # ConversationHandler для всего процесса
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start_session_command)],
        states={
            ASK_API_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_id)],
            ASK_API_HASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_hash)],
            ASK_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_phone)],
            ASK_CODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_code)],
            ASK_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_password)],
        },
        fallbacks=[CommandHandler('cancel', cancel_command)],
        # Добавляем проверку прав на уровне ConversationHandler (на всякий случай)
        # Это потребует небольшой доработки декоратора или явной проверки в entry_points
        # Пока используем декоратор на каждой функции состояния
        conversation_timeout=10 * 60 # 10 минут на ввод всех данных
    )

    application.add_handler(conv_handler)
    # Добавим обработчик для неизвестных команд или текста вне диалога
    async def unknown(update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text("Неизвестная команда. Используйте /start для генерации сессии.")
    application.add_handler(MessageHandler(filters.COMMAND | filters.TEXT, unknown))


    logger.info("Бот-генератор сессий запускается...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()