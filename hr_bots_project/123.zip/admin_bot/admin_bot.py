# hr_bots_project/admin_bot/admin_bot.py

import logging
import os
import json
import docker # Для управления Docker контейнерами
from typing import Dict, Any
import asyncio # Для await asyncio.sleep

from dotenv import load_dotenv
# УБРАЛИ импорты Telethon - они больше не нужны в админ-боте

# Импорты PTB (python-telegram-bot)
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
    ConversationHandler,
    CallbackQueryHandler
)
from telegram.constants import ParseMode

# --- Загрузка переменных окружения ---
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path)
    print(f"Загружен .env файл для admin_bot: {dotenv_path}")
else:
    print(f"Предупреждение: .env файл для admin_bot не найден по пути {dotenv_path}.")

# --- Конфигурация из переменных окружения ---
ADMIN_BOT_TOKEN = os.getenv('ADMIN_BOT_TOKEN')
ADMIN_USER_IDS_STR = os.getenv('ADMIN_USER_IDS')
LOG_LEVEL_STR = os.getenv('LOG_LEVEL', 'INFO').upper()
DOCKER_IMAGE_NAME = os.getenv('DOCKER_AGENT_IMAGE_NAME', 'hr_agent_image:latest')
GEMINI_API_KEY_FOR_AGENTS = os.getenv('GEMINI_API_KEY_FOR_AGENTS')
GEMINI_MODEL_NAME_FOR_AGENTS = os.getenv('GEMINI_MODEL_NAME_FOR_AGENTS', 'gemini-1.5-flash-latest')
AGENT_LOG_LEVEL = os.getenv('AGENT_LOG_LEVEL', 'INFO')

# --- Проверки критичных переменных ---
if not ADMIN_BOT_TOKEN: exit("Критическая ошибка: ADMIN_BOT_TOKEN не установлен.")
if not ADMIN_USER_IDS_STR: exit("Критическая ошибка: ADMIN_USER_IDS не установлен.")
if not DOCKER_IMAGE_NAME: exit("Критическая ошибка: DOCKER_AGENT_IMAGE_NAME не установлен.")
if not GEMINI_API_KEY_FOR_AGENTS: exit("Критическая ошибка: GEMINI_API_KEY_FOR_AGENTS не установлен.")

try:
    ADMIN_USER_IDS = [int(admin_id.strip()) for admin_id in ADMIN_USER_IDS_STR.split(',')]
except ValueError: exit(f"Критическая ошибка: ADMIN_USER_IDS ({ADMIN_USER_IDS_STR}) содержит нечисловое значение.")

# --- Настройка логирования ---
numeric_log_level = getattr(logging, LOG_LEVEL_STR, logging.INFO)
logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=numeric_log_level)
logger = logging.getLogger("AdminBot")
logger.info(f"Уровень логирования Управляющего бота: {LOG_LEVEL_STR}")

# --- Конфигурация Агентов ---
AGENTS_CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'agents_config.json')

# --- Инициализация Docker клиента ---
DOCKER_CLIENT = None
try:
    DOCKER_CLIENT = docker.from_env()
    DOCKER_CLIENT.ping()
    logger.info("Docker клиент успешно инициализирован.")
except docker.errors.DockerException as e:
    logger.error(f"Критическая ошибка: Не удалось подключиться к Docker Engine: {e}")
    logger.error("Убедитесь, что Docker запущен, API доступен и у пользователя есть права.")
    DOCKER_CLIENT = None

# --- Вспомогательные функции для работы с конфигурацией Агентов ---
def save_agents_config(config: Dict[str, Dict[str, Any]]):
    """Сохраняет конфигурацию агентов в JSON файл."""
    try:
        with open(AGENTS_CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        logger.debug(f"Конфигурация агентов сохранена в '{AGENTS_CONFIG_FILE}'.")
    except IOError as e:
        logger.error(f"Ошибка сохранения конфигурации в '{AGENTS_CONFIG_FILE}': {e}")

def load_agents_config() -> Dict[str, Dict[str, Any]]:
    """Загружает конфигурацию агентов из JSON файла."""
    if not os.path.exists(AGENTS_CONFIG_FILE):
        logger.info(f"Файл '{AGENTS_CONFIG_FILE}' не найден, создаю пустой.")
        save_agents_config({})
        return {}
    try:
        with open(AGENTS_CONFIG_FILE, 'r', encoding='utf-8') as f:
            config = json.load(f)
            if not isinstance(config, dict):
                logger.error(f"Файл '{AGENTS_CONFIG_FILE}' неверного формата. Возвращаю пустой.")
                return {}
            return config
    except json.JSONDecodeError:
        logger.error(f"Ошибка декодирования JSON в '{AGENTS_CONFIG_FILE}'. Возвращаю пустой.")
        return {}
    except IOError as e:
        logger.error(f"Ошибка чтения '{AGENTS_CONFIG_FILE}': {e}")
        return {}

def update_agent_status_in_config_file(session_name: str, status_message: str, is_active: bool = None):
    """Обновляет статус конкретного агента в файле конфигурации."""
    agents = load_agents_config()
    if session_name in agents:
        agents[session_name]["status_message"] = status_message
        if is_active is not None:
            agents[session_name]["is_active"] = is_active
        save_agents_config(agents)
    else:
        logger.warning(f"Попытка обновить статус в файле для несуществующего агента: {session_name}")

# --- Декоратор для проверки прав администратора ---
def restricted(func):
    """Декоратор для ограничения доступа к обработчикам только для администраторов."""
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        if user_id not in ADMIN_USER_IDS:
            logger.warning(f"Неавторизованный доступ от user_id: {user_id} к функции {func.__name__}")
            if update.callback_query: await update.callback_query.answer("Нет прав.", show_alert=True)
            elif update.message: await update.message.reply_text("Нет прав.")
            return
        # Проверка Docker клиента
        if hasattr(func, '_requires_docker') and func._requires_docker and not DOCKER_CLIENT:
             err_msg = "Действие невозможно: Docker клиент не инициализирован."
             logger.error(err_msg)
             if update.callback_query: await update.callback_query.answer(err_msg, show_alert=True)
             elif update.message: await update.message.reply_text(err_msg)
             return
        return await func(update, context, *args, **kwargs)
    return wrapped

def requires_docker(func):
    """Маркирует функцию, требующую Docker клиента."""
    func._requires_docker = True
    return func

# --- Константы для Callback Data ---
ACTION_PREFIX_VIEW_AGENT = "view_agent_"
ACTION_PREFIX_TOGGLE_AGENT = "toggle_agent_"
ACTION_PREFIX_CONFIRM_DELETE_AGENT = "confirm_del_agent_"
ACTION_PREFIX_DO_DELETE_AGENT = "do_del_agent_"
ACTION_PREFIX_AGENT_LOGS = "logs_agent_" # TODO: Implement log viewing
ACTION_BACK_TO_LIST = "back_to_list"
ACTION_MAIN_MENU = "main_menu"
ACTION_ADD_AGENT_CONV_START = "add_agent_conv"

# --- Функции для работы с Docker-контейнерами ---
def get_container_name(session_name: str) -> str:
    """Генерирует безопасное имя для Docker контейнера."""
    safe_session_name = "".join(c if c.isalnum() else '_' for c in session_name)
    return f"hr_agent_container_{safe_session_name.lower()}"

def get_container_status_message(container_name: str) -> str:
    """Получает статус Docker контейнера."""
    if not DOCKER_CLIENT: return "Docker клиент недоступен"
    try:
        container = DOCKER_CLIENT.containers.get(container_name)
        return f"Docker: {container.status}"
    except docker.errors.NotFound:
        return "Docker: Контейнер не найден"
    except Exception as e:
        logger.error(f"Ошибка получения статуса контейнера {container_name}: {e}")
        return "Docker: Ошибка статуса"

@requires_docker
async def start_agent_container(session_name: str, agent_config: Dict[str, Any], context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Запускает или перезапускает Docker контейнер для агента."""
    container_name = get_container_name(session_name)
    try:
        existing_container = DOCKER_CLIENT.containers.get(container_name)
        if existing_container.status == 'running':
            logger.info(f"Контейнер {container_name} ({session_name}) уже запущен.")
            update_agent_status_in_config_file(session_name, get_container_status_message(container_name), is_active=True)
            return True
        else:
            logger.info(f"Контейнер {container_name} существует ({existing_container.status}). Запуск...")
            existing_container.start()
            await asyncio.sleep(2)
            update_agent_status_in_config_file(session_name, get_container_status_message(container_name), is_active=True)
            return True
    except docker.errors.NotFound:
        logger.info(f"Контейнер {container_name} не найден. Создание нового...")
    except Exception as e:
        logger.error(f"Ошибка проверки/запуска контейнера {container_name}: {e}")
        update_agent_status_in_config_file(session_name, f"Ошибка Docker: {str(e)[:50]}", is_active=False)
        return False

    env_vars = {
        "TELEGRAM_API_ID": str(agent_config["api_id"]),
        "TELEGRAM_API_HASH": agent_config["api_hash"],
        "TELEGRAM_SESSION_NAME": session_name,
        "GEMINI_API_KEY": GEMINI_API_KEY_FOR_AGENTS,
        "GEMINI_MODEL_NAME": GEMINI_MODEL_NAME_FOR_AGENTS,
        "LOG_LEVEL": AGENT_LOG_LEVEL,
    }
    if agent_config.get("session_string"):
        env_vars["TELEGRAM_SESSION_STRING"] = agent_config["session_string"]
    if agent_config.get("bot_name_override"):
        env_vars["BOT_NAME_OVERRIDE"] = agent_config["bot_name_override"]

    logger.info(f"Запуск контейнера '{container_name}' из '{DOCKER_IMAGE_NAME}' для {session_name}")
    try:
        volume_name = f"{container_name}_telethon_session"
        try: DOCKER_CLIENT.volumes.get(volume_name)
        except docker.errors.NotFound: DOCKER_CLIENT.volumes.create(name=volume_name); logger.info(f"Volume '{volume_name}' создан.")
        volumes_map = {volume_name: {'bind': '/app/sessions', 'mode': 'rw'}}

        container = DOCKER_CLIENT.containers.run(
            DOCKER_IMAGE_NAME, detach=True, name=container_name, environment=env_vars,
            volumes=volumes_map, restart_policy={"Name": "unless-stopped"}
        )
        logger.info(f"Контейнер {container.short_id} ({container_name}) для {session_name} запущен.")
        await asyncio.sleep(2)
        update_agent_status_in_config_file(session_name, get_container_status_message(container_name), is_active=True)
        return True
    except docker.errors.APIError as e:
        logger.error(f"Ошибка Docker API при запуске {session_name}: {e}")
        update_agent_status_in_config_file(session_name, f"Ошибка Docker API: {str(e)[:50]}", is_active=False)
        return False
    except Exception as e_other:
        logger.error(f"Ошибка запуска контейнера {session_name}: {e_other}")
        update_agent_status_in_config_file(session_name, f"Ошибка запуска: {str(e_other)[:50]}", is_active=False)
        return False

@requires_docker
async def stop_agent_container(session_name: str, context: ContextTypes.DEFAULT_TYPE, remove_container_and_volume: bool = False) -> bool:
    """Останавливает и опционально удаляет Docker контейнер и его volume."""
    container_name = get_container_name(session_name)
    try:
        container = DOCKER_CLIENT.containers.get(container_name)
        logger.info(f"Остановка контейнера {container_name} ({session_name})...")
        container.stop(timeout=10)
        logger.info(f"Контейнер {container_name} остановлен.")
        final_status = get_container_status_message(container_name)

        if remove_container_and_volume:
            logger.info(f"Удаление контейнера {container_name}...")
            container.remove()
            logger.info(f"Контейнер {container_name} удален.")
            volume_name = f"{container_name}_telethon_session"
            try:
                volume = DOCKER_CLIENT.volumes.get(volume_name)
                volume.remove(force=True)
                logger.info(f"Docker volume '{volume_name}' удален.")
            except docker.errors.NotFound: logger.info(f"Volume '{volume_name}' не найден.")
            except Exception as ve: logger.error(f"Ошибка удаления volume '{volume_name}': {ve}")
            final_status = "Остановлен и удален (Docker)"

        update_agent_status_in_config_file(session_name, final_status, is_active=False)
        return True
    except docker.errors.NotFound:
        logger.warning(f"Контейнер {container_name} ({session_name}) не найден для остановки.")
        update_agent_status_in_config_file(session_name, "Не найден в Docker", is_active=False)
        return True
    except Exception as e:
        logger.error(f"Ошибка Docker при остановке/удалении {container_name}: {e}")
        update_agent_status_in_config_file(session_name, f"Ошибка остановки Docker: {str(e)[:50]}", is_active=None)
        return False


# --- Функции для отображения меню ---
async def get_main_menu_keyboard() -> InlineKeyboardMarkup:
    """Генерирует клавиатуру главного меню."""
    keyboard = [
        [InlineKeyboardButton("📋 Список HR-Агентов", callback_data=ACTION_BACK_TO_LIST)],
        [InlineKeyboardButton("➕ Добавить HR-Агента", callback_data=ACTION_ADD_AGENT_CONV_START)],
    ]
    return InlineKeyboardMarkup(keyboard)

@restricted
async def start_panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает /start, /panel и callback ACTION_MAIN_MENU."""
    user = update.effective_user
    logger.info(f"Пользователь {user.id} ({user.first_name}) открыл панель управления.")
    reply_markup = await get_main_menu_keyboard()
    text = f"👋 Привет, {user.first_name}! Панель управления HR-Агентами (Docker):"
    if update.callback_query and update.callback_query.data == ACTION_MAIN_MENU:
        try: await query.edit_message_text(text=text, reply_markup=reply_markup)
        except Exception as e: logger.debug(f"Не обновил гл. меню: {e}"); await query.answer()
    elif update.message:
         await update.message.reply_text(text, reply_markup=reply_markup)

@restricted
async def show_agents_list_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, edit_message: bool = True):
    """Отображает/обновляет список агентов, синхронизируя статусы с Docker."""
    query = update.callback_query
    message_to_handle = query.message if query else update.message
    if not message_to_handle: return

    if query: await query.answer("Обновляю список...")

    # Синхронизация статусов с Docker
    agents = load_agents_config()
    if DOCKER_CLIENT:
        statuses_changed = False
        for session_name, config in list(agents.items()):
            container_name = get_container_name(session_name)
            actual_status_msg = get_container_status_message(container_name)
            is_running_docker = "running" in actual_status_msg.lower()
            if config.get("status_message") != actual_status_msg or config.get("is_active") != is_running_docker:
                update_agent_status_in_config_file(session_name, actual_status_msg, is_active=is_running_docker)
                statuses_changed = True
        if statuses_changed: agents = load_agents_config()

    # Формирование меню
    keyboard = []
    if not agents: text = "Список HR-Агентов пуст."
    else:
        text = "📋 Список HR-Агентов (Docker):"
        for session_name, config in agents.items():
            is_active = config.get("is_active", False)
            status_icon = "🟢" if is_active else ("🔴" if "не найден" not in config.get("status_message", "").lower() else "⚪️")
            name = (session_name[:20] + '..') if len(session_name) > 22 else session_name
            keyboard.append([InlineKeyboardButton(f"{status_icon} {name}", callback_data=f"{ACTION_PREFIX_VIEW_AGENT}{session_name}")])
    keyboard.append([InlineKeyboardButton("➕ Добавить HR-Агента", callback_data=ACTION_ADD_AGENT_CONV_START)])
    # Добавляем кнопку "В главное меню", если это не оно само
    not_main_menu = not (query and query.data == ACTION_MAIN_MENU) and not (update.message and update.message.text in ["/start", "/panel"])
    if not_main_menu:
         keyboard.append([InlineKeyboardButton("🏠 В главное меню", callback_data=ACTION_MAIN_MENU)])
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Отправка/редактирование
    try:
        if query and edit_message: await query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)
        elif update.message: await update.message.reply_text(text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)
        elif query and not edit_message: await context.bot.send_message(chat_id=query.message.chat_id, text=text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)
    except Exception as e: logger.warning(f"Не обновил/отправил список: {e}")

@restricted
async def show_agent_management_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, session_name: str):
    """Отображает меню управления для конкретного агента."""
    query = update.callback_query
    if not query: return

    agents = load_agents_config()
    agent_config = agents.get(session_name)
    if not agent_config:
        await query.answer("Агент не найден.", show_alert=True)
        await show_agents_list_menu(update, context)
        return

    # Синхронизация статуса с Docker
    container_name = get_container_name(session_name)
    docker_status_message = get_container_status_message(container_name)
    is_active_docker = "running" in docker_status_message.lower()
    if agent_config.get("status_message") != docker_status_message or agent_config.get("is_active") != is_active_docker :
        update_agent_status_in_config_file(session_name, docker_status_message, is_active=is_active_docker)
        agent_config = load_agents_config().get(session_name) # Перечитать

    is_active = agent_config.get("is_active", False)
    status_icon = "🟢" if is_active else ("🔴" if "не найден" not in docker_status_message.lower() else "⚪️")
    
    text = f"Управление: `{session_name}`\n"
    text += f"Статус: {status_icon} *{agent_config.get('status_message', 'N/A')}*\n"
    text += f"API ID: `{agent_config.get('api_id', 'N/A')}`\n"
    bot_name = agent_config.get('bot_name_override', 'Имя из профиля')
    text += f"Имя: `{bot_name}`\n"
    text += "Сессия: " + ("`Задана`" if agent_config.get('session_string') else "`Не задана (авториз. в логах)`") + "\n"

    keyboard = [
        [InlineKeyboardButton(f"{'Стоп ⏹️' if is_active else 'Старт ▶️'} Агента", callback_data=f"{ACTION_PREFIX_TOGGLE_AGENT}{session_name}")],
        [InlineKeyboardButton(f"📋 Логи Агента", callback_data=f"{ACTION_PREFIX_AGENT_LOGS}{session_name}")],
        [InlineKeyboardButton(f"🗑️ Удалить", callback_data=f"{ACTION_PREFIX_CONFIRM_DELETE_AGENT}{session_name}")],
        [InlineKeyboardButton("⬅️ К списку", callback_data=ACTION_BACK_TO_LIST)]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    try: await query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)
    except Exception as e: logger.debug(f"Не обновил меню агента: {e}"); await query.answer()


# --- Обработчик CallbackQuery ---
@restricted
async def button_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатия на все inline-кнопки."""
    query = update.callback_query
    await query.answer() # Быстрый ответ на callback
    data = query.data
    user = query.from_user
    logger.info(f"Кнопка: '{data}' от {user.id} ({user.first_name})")

    # Проверка Docker клиента для действий, требующих его
    docker_actions = (ACTION_PREFIX_TOGGLE_AGENT, ACTION_PREFIX_CONFIRM_DELETE_AGENT, ACTION_PREFIX_DO_DELETE_AGENT, ACTION_PREFIX_AGENT_LOGS)
    if data.startswith(docker_actions) and not DOCKER_CLIENT:
        await query.message.reply_text("Критическая ошибка: Docker клиент не инициализирован.")
        return

    # Маршрутизация по callback_data
    if data == ACTION_BACK_TO_LIST:
        await show_agents_list_menu(update, context)
    elif data == ACTION_MAIN_MENU:
        await start_panel_command(update, context) # Используем функцию для показа главного меню
    elif data == ACTION_ADD_AGENT_CONV_START:
        if not DOCKER_CLIENT: await query.message.reply_text("Docker клиент не инициализирован."); return
        await context.bot.send_message(chat_id=update.effective_chat.id, text="Для добавления агента отправьте /add_agent_start")
    elif data.startswith(ACTION_PREFIX_VIEW_AGENT):
        session_name = data[len(ACTION_PREFIX_VIEW_AGENT):]
        await show_agent_management_menu(update, context, session_name)
    elif data.startswith(ACTION_PREFIX_TOGGLE_AGENT):
        session_name = data[len(ACTION_PREFIX_TOGGLE_AGENT):]
        agents = load_agents_config()
        if session_name in agents:
            should_start = not agents[session_name].get("is_active", False)
            action_text = "Запуск" if should_start else "Остановка"
            action_func = start_agent_container if should_start else stop_agent_container
            update_agent_status_in_config_file(session_name, f"Попытка {action_text.lower()} Docker...", is_active=should_start)
            action_result = await action_func(session_name, agents[session_name] if should_start else context, context)
            await query.answer(f"{action_text} агента {session_name}..." if action_result else f"Ошибка {action_text.lower()}!", show_alert=not action_result)
            await asyncio.sleep(1) # Даем Docker время обновить статус
            await show_agent_management_menu(update, context, session_name) # Обновляем меню
        else:
            await query.answer("Агент не найден!", show_alert=True)
            await show_agents_list_menu(update, context)
    elif data.startswith(ACTION_PREFIX_CONFIRM_DELETE_AGENT):
        session_name = data[len(ACTION_PREFIX_CONFIRM_DELETE_AGENT):]
        keyboard = [[InlineKeyboardButton(f"✅ Да, удалить {session_name[:15]}..", callback_data=f"{ACTION_PREFIX_DO_DELETE_AGENT}{session_name}"),
                     InlineKeyboardButton("❌ Отмена", callback_data=f"{ACTION_PREFIX_VIEW_AGENT}{session_name}")]]
        await query.edit_message_text(text=f"Удалить `{session_name}`? (Конфиг, контейнер, volume)", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)
    elif data.startswith(ACTION_PREFIX_DO_DELETE_AGENT):
        session_name = data[len(ACTION_PREFIX_DO_DELETE_AGENT):]
        agents_cfg = load_agents_config()
        if session_name in agents_cfg:
            logger.info(f"Удаление агента {session_name} админом {user.id}...")
            stopped_removed_ok = await stop_agent_container(session_name, context, remove_container_and_volume=True)
            if not stopped_removed_ok: logger.warning(f"Ошибки при удалении контейнера {session_name}, но конфиг удаляем.")
            del agents_cfg[session_name]
            save_agents_config(agents_cfg)
            await query.answer(f"Агент {session_name} удален.")
            await show_agents_list_menu(update, context) # Показать обновленный список
        else:
            await query.answer("Агент уже удален.", show_alert=True)
            await show_agents_list_menu(update, context)
    elif data.startswith(ACTION_PREFIX_AGENT_LOGS):
         session_name = data[len(ACTION_PREFIX_AGENT_LOGS):]
         container_name = get_container_name(session_name)
         log_text = f"Последние логи для `{session_name}` (контейнер: `{container_name}`):\n"
         if DOCKER_CLIENT:
             try:
                 container = DOCKER_CLIENT.containers.get(container_name)
                 # Берем последние ~15 строк логов
                 logs = container.logs(tail=15).decode('utf-8', errors='ignore')
                 log_text += f"```\n{logs or '(Логи пусты)'}\n```"
             except docker.errors.NotFound: log_text += "_Контейнер не найден._"
             except Exception as e: log_text += f"_Ошибка получения логов: {e}_"
         else: log_text += "_Docker клиент не доступен._"
         # Отправляем логи новым сообщением
         await query.message.reply_text(log_text, parse_mode=ParseMode.MARKDOWN)
         await query.answer("Логи (tail=15) отправлены.") # Ответ на кнопку

# --- Логика добавления Агента (ConversationHandler) ---
# В этом варианте мы НЕ АВТОРИЗУЕМ через бота, а запрашиваем строку сессии
(SESSION_NAME_STATE, API_ID_STATE, API_HASH_STATE, SESSION_STRING_STATE, BOT_NAME_STATE) = map(chr, range(5)) # 5 состояний

@restricted
async def add_agent_start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Начинает диалог добавления нового агента."""
    if not DOCKER_CLIENT:
        await update.message.reply_text("Не могу начать: Docker клиент не инициализирован.")
        return ConversationHandler.END
    await update.message.reply_text(
        "Добавление нового HR-Агента (Docker).\n"
        "1. Введите **уникальное имя сессии** (латиница/цифры/_, начинается с буквы).\n\n"
        "Для отмены: /cancel."
    )
    return SESSION_NAME_STATE

async def received_session_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод имени сессии."""
    session_name = update.message.text.strip()
    if not session_name or not all(c.isalnum() or c == '_' for c in session_name) or not (session_name[0].isalpha() if session_name else False) :
        await update.message.reply_text("Невалидное имя. Латиница/цифры/_, начинается с буквы. Еще раз или /cancel.")
        return SESSION_NAME_STATE
    agents = load_agents_config()
    if session_name in agents:
        await update.message.reply_text(f"Агент '{session_name}' уже существует. Другое имя или /cancel.")
        return SESSION_NAME_STATE
    context.user_data['new_agent_session_name'] = session_name
    await update.message.reply_text(f"Имя сессии: `{session_name}`.\n2. Введите **API ID** (число) или /cancel.", parse_mode=ParseMode.MARKDOWN)
    return API_ID_STATE

async def received_api_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод API ID."""
    try:
        api_id = int(update.message.text.strip())
        if api_id <= 0: raise ValueError("API ID < 0")
        context.user_data['new_agent_api_id'] = api_id
        await update.message.reply_text(f"API ID: `{api_id}`.\n3. Введите **API HASH** (строка, ~32 hex символа) или /cancel.", parse_mode=ParseMode.MARKDOWN)
        return API_HASH_STATE
    except ValueError as e:
        await update.message.reply_text(f"API ID должен быть полож. числом ({e}). Еще раз или /cancel.")
        return API_ID_STATE

async def received_api_hash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод API Hash."""
    api_hash = update.message.text.strip()
    # Простая проверка
    if not api_hash or len(api_hash) < 30 or not all(c in '0123456789abcdefABCDEF' for c in api_hash):
        await update.message.reply_text("API HASH невалиден (hex, ~32 символа). Еще раз или /cancel.")
        return API_HASH_STATE
    context.user_data['new_agent_api_hash'] = api_hash
    # Пропускаем проверку API через Telethon здесь для упрощения
    await update.message.reply_text(
        "API HASH получен.\n"
        "4. Введите **строку сессии Telethon** (если есть, для входа без кода/пароля).\n"
        "Если нет (агент авторизуется через логи контейнера при первом запуске), напишите '`-`' или '`пропустить`'.\n\n"
        "Для отмены: /cancel.",
        parse_mode=ParseMode.MARKDOWN
    )
    return SESSION_STRING_STATE

async def received_session_string(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    """Обрабатывает ввод строки сессии."""
    session_string_input = update.message.text.strip()
    session_string = None
    if session_string_input.lower() not in ['-', 'пропустить', 'skip', 'none', '']:
        session_string = session_string_input
        logger.info(f"Получена строка сессии для нового агента: ...{session_string_input[-10:]}")
    else:
        logger.info("Строка сессии пропущена.")
    context.user_data['new_agent_session_string'] = session_string
    await update.message.reply_text(
        "Строка сессии обработана.\n"
        "5. Введите **имя, которым бот будет представляться** (например, 'Ольга, HR').\n"
        "Если пропустить (отправить '`-`'), бот попытается использовать имя из профиля Telegram.\n\n"
        "Для отмены: /cancel."
    )
    return BOT_NAME_STATE

async def received_bot_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Обрабатывает ввод имени бота и завершает диалог."""
    bot_name_override = None
    if update.message.text and update.message.text.strip().lower() not in ['-', 'пропустить', 'skip', 'none', '']:
        bot_name_override = update.message.text.strip()

    agents = load_agents_config()
    api_id = context.user_data.get('new_agent_api_id')
    api_hash = context.user_data.get('new_agent_api_hash')
    session_name = context.user_data.get('new_agent_session_name')
    session_string = context.user_data.get('new_agent_session_string')
    if not all([api_id, api_hash, session_name]):
        await update.message.reply_text("Ошибка: Потеряны данные. /add_agent_start.")
        context.user_data.clear(); return ConversationHandler.END

    # Сохраняем данные нового агента
    new_agent_data = {
        "api_id": api_id, "api_hash": api_hash, "session_string": session_string,
        "bot_name_override": bot_name_override, "is_active": False, # Не активен по умолчанию
        "status_message": "Добавлен, не запускался"
    }
    agents[session_name] = new_agent_data
    save_agents_config(agents)

    name_disp = f"`{bot_name_override}`" if bot_name_override else "`имя из профиля`"
    sess_info = "с строкой сессии" if session_string else "(без строки сессии)"
    await update.message.reply_text(f"✅ Агент `{session_name}` {sess_info} (имя: {name_disp}) добавлен!", parse_mode=ParseMode.MARKDOWN)
    context.user_data.clear()
    await show_agents_list_menu(update, context, edit_message=False) # Показываем список новым сообщением
    return ConversationHandler.END

async def cancel_add_agent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Отменяет диалог добавления агента."""
    await update.message.reply_text("Добавление отменено.")
    context.user_data.clear()
    await start_panel_command(update, context) # Показываем главное меню
    return ConversationHandler.END


# --- Точка входа ---
def main() -> None:
    """Запускает Управляющего бота."""
    if not DOCKER_CLIENT:
        logger.critical("Запуск невозможен: Docker клиент не инициализирован.")
        return

    application = Application.builder().token(ADMIN_BOT_TOKEN).build()

    # ConversationHandler для добавления агента (без шагов авторизации)
    add_agent_conv_handler = ConversationHandler(
        entry_points=[CommandHandler('add_agent_start', add_agent_start_command)],
        states={
            SESSION_NAME_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_session_name)],
            API_ID_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_id)],
            API_HASH_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_hash)],
            SESSION_STRING_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_session_string)],
            BOT_NAME_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_bot_name)],
        },
        fallbacks=[CommandHandler('cancel', cancel_add_agent)],
        conversation_timeout=10 * 60 # 10 минут на диалог
    )

    # Регистрируем обработчики
    application.add_handler(CommandHandler(["start", "panel"], start_panel_command))
    application.add_handler(CommandHandler("list_agents", lambda u,c: show_agents_list_menu(u, c, edit_message=False)))
    application.add_handler(add_agent_conv_handler)
    application.add_handler(CallbackQueryHandler(button_callback_handler)) # Единый обработчик кнопок

    logger.info(f"Управляющий бот (Docker) запущен. Образ агента: {DOCKER_IMAGE_NAME}")
    # Запуск бота
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()