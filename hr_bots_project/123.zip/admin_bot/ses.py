from telethon.sync import TelegramClient # Используем sync для простоты в консоли
from telethon.sessions import StringSession

API_ID = 28242182  # Ваш API ID
API_HASH = '661baec710b8a0bb22ab4465b3ee8f57' # Ваш API Hash


1ApWapzMBu2Ak25tlMEEoPf2n28GwAPky7PVR7KlxRo3rXEzREtFm3uBsI5n-vqqTfgGi8RJuVMpeq4T2X6u_Lzu7kyMBeHHb7kkISvSO3ZyK-yVaZJMNNMC7QnI_apJ5UhZRw3KFUw7DokUoD7aKKtOt9K9WxhWH5g6rzRRqhaAbAaiXVY9r--utS1MBYsv9LU6cWcUCzjZjnFUqEW9qDZrTHXHKagT3zGedKrpD1wqO2hbOQ88cSbSEyvRD6Sgxvg1zLPpiL0BluR5QjY7ttnffglyO0Yn0j_oKHQWmCjbwEPQjfz3rpciLEptv5WGDzSMqNNbAWXnXbu6dcu4Y-PLIubagjpA=

print("Создание клиента с сессией в памяти...")
# Используем StringSession(), чтобы сессия не сохранялась в файл локально
client = TelegramClient(StringSession(), API_ID, API_HASH) 

async def main():
    print("Подключение к Telegram...")
    await client.connect()
    if not await client.is_user_authorized():
        phone_number = input('Введите номер телефона (+...): ')
        await client.send_code_request(phone_number)
        print("Код отправлен.")
        auth_code = input('Введите полученный код: ')
        try:
            await client.sign_in(phone_number, auth_code)
        except Exception as e: # Обработка возможной ошибки (например, нужен 2FA)
            if 'password' in str(e).lower(): # Простая проверка на запрос пароля
                 password = input('Введите пароль 2FA: ')
                 await client.sign_in(password=password)
            else:
                 print(f"Ошибка входа: {e}")
                 return # Выход при ошибке

    # Проверка авторизации
    if await client.is_user_authorized():
         print("Авторизация успешна!")
         me = await client.get_me()
         print(f"Вы вошли как: {me.first_name} (@{me.username})")
         # Самое важное - вывод строки сессии
         session_string = client.session.save()
         print("\nВАША СТРОКА СЕССИИ TELETHON:\n")
         print(session_string)
         print("\nСкопируйте эту строку и сохраните в безопасном месте!")
    else:
         print("Авторизация не удалась.")

    await client.disconnect()
    print("Клиент отключен.")

# Запускаем асинхронную функцию main
import asyncio
asyncio.run(main()) 
# В некоторых системах или версиях Python может потребоваться:
# loop = asyncio.get_event_loop()
# loop.run_until_complete(main())