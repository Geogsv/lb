# hr_bots_project/agent_bot/user_hr_bot.py
import asyncio
import logging
import os
import random
import json # Для отладки истории
from datetime import datetime

from dotenv import load_dotenv # Для локального тестирования
from telethon import TelegramClient, events
from telethon.sessions import StringSession # Будем использовать StringSession или FileSession
from telethon.errors import (
    UserNotParticipantError, ChannelPrivateError, ChatWriteForbiddenError,
    UserIsBlockedError, FloodWaitError, AuthKeyError, UnauthorizedError, UserDeactivatedError, SessionExpiredError
)
import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold # Для safety_settings

# --- Загрузка переменных окружения (для локального запуска) ---
LOCAL_DEV_ENV_PATH = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(LOCAL_DEV_ENV_PATH):
    load_dotenv(LOCAL_DEV_ENV_PATH)
    # Используем имя сессии из ENV для логгера даже при локальном запуске
    session_name_for_log = os.getenv('TELEGRAM_SESSION_NAME', 'local_unknown')
    print(f"[Agent {session_name_for_log}] Загружен локальный .env файл: {LOCAL_DEV_ENV_PATH}")
else:
    session_name_for_log = os.getenv('TELEGRAM_SESSION_NAME', 'docker_unknown')


# --- Чтение конфигурации из переменных окружения ---
try:
    TELEGRAM_API_ID = int(os.getenv('TELEGRAM_API_ID'))
    TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
    # Имя сессии используется для файла сессии и для логгера
    TELEGRAM_SESSION_NAME = os.getenv('TELEGRAM_SESSION_NAME')
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')

    # Опциональные переменные
    TELEGRAM_SESSION_STRING = os.getenv('TELEGRAM_SESSION_STRING') # Строка сессии от админ-бота
    GEMINI_MODEL_NAME = os.getenv('GEMINI_MODEL_NAME', 'gemini-1.5-flash-latest')
    BOT_NAME_FROM_ENV = os.getenv('BOT_NAME_OVERRIDE') # Имя, заданное админом
    AGENT_LOG_LEVEL_STR = os.getenv('LOG_LEVEL', 'INFO').upper()

except TypeError:
    # Логгер еще не настроен, используем print
    print(f"Критическая ошибка [Agent {TELEGRAM_SESSION_NAME or 'Unknown'}]: TELEGRAM_API_ID не число.")
    exit(1)

# Проверка обязательных переменных
missing_vars_list = [var for var, val in {"TELEGRAM_API_ID": TELEGRAM_API_ID, "TELEGRAM_API_HASH": TELEGRAM_API_HASH,"TELEGRAM_SESSION_NAME": TELEGRAM_SESSION_NAME,"GEMINI_API_KEY": GEMINI_API_KEY}.items() if not val]
if missing_vars_list:
    print(f"Критическая ошибка [Agent {TELEGRAM_SESSION_NAME or 'Unknown'}]: Переменные не установлены: {', '.join(missing_vars_list)}")
    exit(1)

# --- Настройка логирования Агента ---
agent_numeric_log_level = getattr(logging, AGENT_LOG_LEVEL_STR, logging.INFO)
# Создаем логгер с именем сессии
logger = logging.getLogger(f"Agent_{TELEGRAM_SESSION_NAME}")
logger.setLevel(agent_numeric_log_level)
# Настраиваем обработчик и форматтер, только если логгер еще не настроен
if not logger.hasHandlers():
    log_formatter = logging.Formatter(f'[%(levelname)5s/%(asctime)s] %(name)s: %(message)s')
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(log_formatter)
    logger.addHandler(stream_handler)
    logger.propagate = False # Избегаем дублирования с root логгером
logger.info(f"Уровень логирования агента установлен на: {AGENT_LOG_LEVEL_STR}")


# --- Глобальные переменные Агента ---
BOT_TELEGRAM_NAME = BOT_NAME_FROM_ENV # Начальное значение
client: TelegramClient = None

# --- Конфигурация Gemini ---
try:
    genai.configure(api_key=GEMINI_API_KEY)
    gemini_model = genai.GenerativeModel(GEMINI_MODEL_NAME)
    logger.info(f"Модель Gemini '{GEMINI_MODEL_NAME}' инициализирована.")
except Exception as e:
    logger.critical(f"Критическая ошибка инициализации Gemini: {e}", exc_info=True)
    exit(1) # Выход, если Gemini не работает

# --- СЦЕНАРИЙ И ПРОМПТЫ ДЛЯ HR-БОТА ---
RECRUITMENT_CONTEXT = "кандидат обратился по поводу открытой вакансии или с интересом к работе в компании"
IMPROVED_SYSTEM_PROMPT_TEMPLATE = f"""\
Ты — {{bot_name}}, дружелюбный и профессиональный ассистент по подбору персонала. Твоя главная задача — мягко провести первичное анкетирование кандидата, который обратился по поводу работы, и затем поддерживать с ним контакт ("держать теплым"), сообщая о дальнейших шагах и ссылаясь на текущую загруженность команды рекрутеров.
Твоя речь должна быть естественной, вежливой и располагающей. Используй смайлики уместно (например, 😊, 👍, 😉).
Задавай вопросы анкеты по одному. Внимательно читай ответы кандидата и обязательно реагируй на них перед тем, как задать следующий вопрос или перейти к следующему этапу.
Если кандидат спрашивает о деталях вакансии, на которые ты не можешь ответить, или задает сложные вопросы, мягко сообщи, что эту информацию ему предоставит рекрутер при личном общении, а твоя задача — собрать первичные данные для ускорения процесса. Пример ответа: "Это отличный вопрос! Детали по условиям и задачам лучше обсудить напрямую с рекрутером, который сможет дать самую точную информацию. Я пока соберу основные данные, чтобы ускорить наше знакомство, хорошо? 😊"
После завершения анкеты твоя задача — "подогревать" кандидата: вежливо сообщить, что его данные переданы, и рекрутер свяжется с ним в ближайшее возможное время. Упомяни, что сейчас у команды высокая загрузка, но его кандидатура очень важна. Пример ответа: "Спасибо большое за ответы! Я передал(а) всю информацию нашим рекрутерам. Сейчас у нас довольно много обращений, но мы обязательно рассмотрим вашу кандидатуру и свяжемся с вами, как только появится возможность. Ценим ваше терпение! 👍"
Если кандидат пишет тебе снова до того, как с ним связался рекрутер, еще раз поблагодари за терпение, подтверди, что его анкета в работе, и сошлись на занятость. Пример: "Здравствуйте! Да, помню вас. Ваша анкета у команды, просто сейчас действительно большая загруженность. Как только рекрутер освободится, он обязательно с вами свяжется. Спасибо за ожидание! 😉"
Не выдумывай информацию о себе (твоя компания, где ты работаешь и т.д.), если тебя спросят. Сосредоточься на процессе анкетирования и подогрева.
Твои ответы должны быть только текстом. Не используй markdown. Старайся делать свои реплики не слишком длинными (2-4 предложения).
Твоя текущая задача: {{current_task_instruction}}
Контекст обращения пользователя: {RECRUITMENT_CONTEXT}.
"""

SCENARIO = {
    "name": "HR Анкета с Gemini",
    "start_question_id": 1,
    "anketa_completed_status_id": 0, # ID статуса "анкета завершена"
    "greeting_instruction_template": "Кандидат только что написал (скорее всего, по поводу работы). Поприветствуй его очень дружелюбно и профессионально от имени {{bot_name}}. Поблагодари за интерес к компании/вакансии. Сообщи, что для начала хотел бы задать несколько вопросов, чтобы лучше понять его профиль и ускорить процесс. Затем сразу переходи к первому вопросу анкеты.",
    "warming_up_instruction_template": "Кандидат {{action_description}}. Твоя задача — поддержать его интерес и проявить заботу от имени {{bot_name}}. Поблагодари за терпение/сообщение. Сообщи, что его анкета/обращение находится в работе у команды рекрутеров. Подчеркни, что сейчас у команды высокая загрузка, но они обязательно свяжутся с ним в ближайшее возможное время, как только появится возможность. Заверь, что его кандидатура важна.",
    "questions": { # Темы вопросов для Gemini
        1: {"id": 1, "topic_for_gemini": "имя кандидата (как к нему обращаться)", "next_question_id": 2},
        2: {"id": 2, "topic_for_gemini": "возраст кандидата (полных лет)", "next_question_id": 3},
        3: {"id": 3, "topic_for_gemini": "город проживания кандидата", "next_question_id": 4},
        4: {"id": 4, "topic_for_gemini": "на какую должность или направление кандидат претендует (или его основной опыт/интерес)", "next_question_id": 0}, # 0 = anketa_completed_status_id
    }
}
# Состояние диалогов храним в памяти для простоты (в Docker оно будет теряться при перезапуске контейнера)
# Для сохранения состояния между перезапусками контейнера нужен внешний механизм (БД, Redis)
user_states = {} # { user_id: {"current_question_id": int, "answers": {}, "chat_history": []} }

# --- Функции Агента ---
def get_user_state(user_id: int) -> dict:
    """Получает или инициализирует состояние диалога для пользователя."""
    if user_id not in user_states:
        user_states[user_id] = {
            "current_question_id": SCENARIO["start_question_id"],
            "answers": {},
            "chat_history": [],
            "last_activity": datetime.now()
        }
        logger.info(f"Новый кандидат {user_id}, начало HR сценария.")
    user_states[user_id]["last_activity"] = datetime.now()
    return user_states[user_id]

def add_to_chat_history(user_id: int, role: str, text: str):
    """Добавляет сообщение в историю чата для Gemini."""
    if user_id in user_states:
        if text and text.strip():
            user_states[user_id]["chat_history"].append({"role": role, "parts": [{"text": text.strip()}]})
            max_history_items = 12 # Увеличим историю
            if len(user_states[user_id]["chat_history"]) > max_history_items:
                user_states[user_id]["chat_history"] = user_states[user_id]["chat_history"][-max_history_items:]
        else:
            logger.debug(f"Проигнорировано пустое сообщение для истории user {user_id} от {role}.")

def update_user_answer(user_id: int, question_id: int, answer: str):
    """Сохраняет ответ пользователя на конкретный вопрос."""
    if user_id in user_states:
        # Логируем только часть ответа для приватности
        logger.info(f"Ответ кандидата {user_id} на QID {question_id} сохранен: '{answer[:30]}...'")
        user_states[user_id]["answers"][question_id] = answer

def advance_user_question(user_id: int, next_question_id: int):
    """Переводит пользователя на следующий шаг сценария."""
    if user_id in user_states:
        logger.info(f"Кандидат {user_id}: переход с QID {user_states[user_id]['current_question_id']} на QID {next_question_id}")
        user_states[user_id]["current_question_id"] = next_question_id

async def generate_gemini_response(user_id: int, current_task_instruction: str, user_message_text_for_history: str = None) -> str:
    """Генерирует ответ с помощью Gemini API."""
    global BOT_TELEGRAM_NAME
    # Установка имени по умолчанию, если оно не определено
    if not BOT_TELEGRAM_NAME: BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}"

    state = get_user_state(user_id)
    if user_message_text_for_history:
        add_to_chat_history(user_id, "user", user_message_text_for_history)

    system_prompt_filled = IMPROVED_SYSTEM_PROMPT_TEMPLATE.format(
        bot_name=BOT_TELEGRAM_NAME,
        current_task_instruction=current_task_instruction
    )
    contents_for_gemini = [{"role": "user", "parts": [{"text": system_prompt_filled}]}]
    
    temp_combined_history = []
    last_role = "user" 
    for entry in state["chat_history"]:
        if entry["role"] == last_role and temp_combined_history:
            logger.warning(f"Нарушение чередования ролей для {user_id}. Пропуск.")
            continue
        temp_combined_history.append(entry)
        last_role = entry["role"]
    contents_for_gemini.extend(temp_combined_history)

    logger.debug(f"Запрос к Gemini для кандидата {user_id}. Задача: {current_task_instruction}. История: {len(temp_combined_history)} сообщ.")

    try:
        response = await gemini_model.generate_content_async(
            contents=contents_for_gemini,
            generation_config=genai.types.GenerationConfig(temperature=0.7, top_p=0.95),
            safety_settings={ category: HarmBlockThreshold.BLOCK_NONE for category in HarmCategory }
        )
        # Извлечение текста ответа
        bot_text = "".join(part.text for part in response.candidates[0].content.parts) if response.candidates and response.candidates[0].content and response.candidates[0].content.parts else ""
        
        if not bot_text: # Обработка пустого ответа или блокировки
            block_reason_msg = "Причина неизвестна"
            if response.prompt_feedback and response.prompt_feedback.block_reason:
                block_reason_msg = response.prompt_feedback.block_reason.name
                logger.warning(f"Запрос к Gemini заблокирован для {user_id}: {block_reason_msg}")
                return f"(Ответ не сгенерирован из-за ограничений: {block_reason_msg})"
            else:
                logger.warning(f"Gemini вернул пустой текст для {user_id} без блокировки.")
                return "(Произошла заминка, повторите?)"

        add_to_chat_history(user_id, "model", bot_text) # Добавляем валидный ответ в историю
        return bot_text.strip()

    except Exception as e:
        logger.error(f"Ошибка при запросе к Gemini API для {user_id}: {e}", exc_info=True)
        return f"Прошу прощения, возникла техническая проблема. ({BOT_TELEGRAM_NAME})"

async def process_user_message_logic(user_id: int, message_text: str) -> str:
    """Обрабатывает сообщение пользователя и определяет задачу для Gemini."""
    global BOT_TELEGRAM_NAME
    state = get_user_state(user_id)
    current_q_id = state["current_question_id"]
    instruction = ""

    if current_q_id == SCENARIO["anketa_completed_status_id"]: # Режим подогрева
        logger.info(f"Кандидат {user_id} (анкета завершена) пишет снова.")
        action_desc = "снова написал после завершения анкеты"
        instruction = SCENARIO["warming_up_instruction_template"].format(action_description=action_desc, bot_name=BOT_TELEGRAM_NAME)
    elif current_q_id in SCENARIO["questions"]: # Анкетирование
        q_data = SCENARIO["questions"][current_q_id]
        update_user_answer(user_id, current_q_id, message_text.strip())
        next_q_id = q_data["next_question_id"]
        if next_q_id == SCENARIO["anketa_completed_status_id"]: # Завершение анкеты
            logger.info(f"Кандидат {user_id} завершил анкету.")
            action_desc = "только что завершил(а) анкету"
            warming_instr = SCENARIO["warming_up_instruction_template"].format(action_description=action_desc, bot_name=BOT_TELEGRAM_NAME)
            instruction = f"Кандидат ответил на '{q_data['topic_for_gemini']}'. Отреагируй. Затем переходи к 'подогреву': \"{warming_instr}\"."
        else: # Следующий вопрос
            next_q_data = SCENARIO["questions"][next_q_id]
            instruction = f"Кандидат ответил на '{q_data['topic_for_gemini']}'. Отреагируй. Затем задай вопрос о '{next_q_data['topic_for_gemini']}'."
        advance_user_question(user_id, next_q_id)
    else: # Ошибка сценария
        logger.error(f"Некорректный QID {current_q_id} для {user_id}. Сброс.")
        advance_user_question(user_id, SCENARIO["start_question_id"])
        greeting_instr = SCENARIO["greeting_instruction_template"].format(bot_name=BOT_TELEGRAM_NAME)
        first_q_topic = SCENARIO["questions"][SCENARIO["start_question_id"]]["topic_for_gemini"]
        instruction = f"{greeting_instr} Первый вопрос о '{first_q_topic}'. (Произошел сбой, начнем заново)."
        bot_response = await generate_gemini_response(user_id, instruction, None)
        advance_user_question(user_id, SCENARIO["questions"][SCENARIO["start_question_id"]]["next_question_id"])
        return bot_response
        
    return await generate_gemini_response(user_id, instruction, message_text)

# --- Основная логика работы Агента (запуск Telethon) ---
async def actual_agent_work():
    """Основная функция, запускающая и управляющая клиентом Telethon."""
    global BOT_TELEGRAM_NAME, client 
    
    logger.info(f"Запуск основной логики агента '{TELEGRAM_SESSION_NAME}'...")
    
    # Определяем объект сессии: строка из ENV или файл в /app/sessions/
    session_to_use = None
    if TELEGRAM_SESSION_STRING:
        logger.info("Используется строка сессии из ENV.")
        session_to_use = StringSession(TELEGRAM_SESSION_STRING)
    else:
        # Путь к файлу сессии внутри папки /app/sessions (созданной в Dockerfile)
        session_dir = "/app/sessions"
        if not os.path.exists(session_dir): # Создаем на всякий случай, если не в Docker
             try: os.makedirs(session_dir); logger.info(f"Создана директория {session_dir}")
             except OSError: session_dir="." # Fallback в текущую папку
        session_file_path = os.path.join(session_dir, TELEGRAM_SESSION_NAME)
        logger.info(f"Используется файл сессии: {session_file_path}.session")
        session_to_use = session_file_path

    # Инициализация клиента
    client = TelegramClient(session_to_use, TELEGRAM_API_ID, TELEGRAM_API_HASH)
    logger.info("Клиент Telethon инициализирован.")

    # --- Обработчик входящих сообщений ---
    @client.on(events.NewMessage(incoming=True, forwards=False))
    async def handle_new_message(event):
        global BOT_TELEGRAM_NAME
        if not client or not client.is_connected():
             logger.warning("Сообщение получено, но клиент не готов.")
             return 
             
        if event.is_private and not event.message.out:
            user_id = event.sender_id
            message_text = event.text.strip() if event.text else ""
            logger.info(f"Сообщение от кандидата {user_id}: '{message_text[:100]}...'")

            # Установка имени бота, если еще не задано
            if not BOT_TELEGRAM_NAME:
                try:
                     if await client.is_user_authorized():
                         me_user = await client.get_me()
                         if me_user: BOT_TELEGRAM_NAME = me_user.first_name + (f" {me_user.last_name}" if me_user.last_name else "")
                         else: BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}"
                     else: BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}"
                     logger.info(f"Имя бота динамически установлено: {BOT_TELEGRAM_NAME}")
                except Exception as e: logger.warning(f"Не удалось получить имя бота: {e}")
                if not BOT_TELEGRAM_NAME: BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}"

            state = get_user_state(user_id)
            bot_reply_text = ""

            # Логика ответа
            if not state["chat_history"] and state["current_question_id"] == SCENARIO["start_question_id"]: # Первый контакт
                greeting_instr = SCENARIO["greeting_instruction_template"].format(bot_name=BOT_TELEGRAM_NAME)
                first_q_id = SCENARIO["start_question_id"]
                first_q_topic = SCENARIO["questions"][first_q_id]["topic_for_gemini"]
                task = f"{greeting_instr} Первый вопрос о '{first_q_topic}'."
                bot_reply_text = await generate_gemini_response(user_id, task, None)
                advance_user_question(user_id, SCENARIO["questions"][first_q_id]["next_question_id"])
            elif not message_text: # Пустое/нетекст
                task = f"Кандидат отправил нетекстовое. Скажи от имени {BOT_TELEGRAM_NAME}, что понимаешь текст."
                bot_reply_text = await generate_gemini_response(user_id, task, "[Кандидат отправил нетекстовое сообщение]")
            else: # Обычное сообщение
                bot_reply_text = await process_user_message_logic(user_id, message_text)

            # Отправка ответа
            if bot_reply_text:
                await asyncio.sleep(random.uniform(1.0, 2.0))
                try: await event.respond(bot_reply_text); logger.info(f"Ответ для {user_id} отправлен.")
                except (ChatWriteForbiddenError, UserIsBlockedError) as e: logger.warning(f"Не удалось отправить {user_id} (заблокирован?): {e}")
                except FloodWaitError as e_flood:
                     wait_time = e_flood.seconds + random.uniform(1, 3)
                     logger.warning(f"FloodWait при отправке {user_id}. Ждем {wait_time:.1f} сек.")
                     await asyncio.sleep(wait_time)
                     try: await event.respond(bot_reply_text); logger.info(f"Отправлен ответ {user_id} после FloodWait.")
                     except Exception as e_retry: logger.error(f"Ошибка повторной отправки {user_id}: {e_retry}")
                except Exception as e_respond: logger.error(f"Ошибка отправки {user_id}: {e_respond}")
            else: logger.warning(f"Пустой ответ для {user_id}.")

    # --- Запуск клиента Telethon ---
    is_authorized = False
    try:
        logger.info(f"Попытка запуска клиента '{TELEGRAM_SESSION_NAME}'...")
        # Если есть строка сессии, Telethon попытается использовать ее.
        # Если ее нет или она невалидна, и lambda-функции переданы, он запросит авторизацию.
        await client.start(
            phone=lambda: input(f"[{TELEGRAM_SESSION_NAME}] Введите номер телефона: ") if not TELEGRAM_SESSION_STRING else None,
            password=lambda: input(f"[{TELEGRAM_SESSION_NAME}] Введите пароль 2FA: ") if not TELEGRAM_SESSION_STRING else None,
            code_callback=lambda: input(f"[{TELEGRAM_SESSION_NAME}] Введите код: ") if not TELEGRAM_SESSION_STRING else None
        )
        is_authorized = await client.is_user_authorized() # Проверяем результат
        
        if not is_authorized:
            logger.error(f"Авторизация '{TELEGRAM_SESSION_NAME}' НЕ УДАЛАСЬ. Проверьте логи/консоль на запросы кода/пароля или валидность строки сессии. Агент остановлен.")
            return # Завершаем работу, если не авторизован

        # Установка имени бота
        if not BOT_NAME_FROM_ENV:
            try: me = await client.get_me(); BOT_TELEGRAM_NAME = me.first_name + (f" {me.last_name}" if me.last_name else "")
            except Exception as e: logger.warning(f"Не удалось получить имя из профиля: {e}")
        if not BOT_TELEGRAM_NAME: BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}"
        logger.info(f"Агент '{BOT_TELEGRAM_NAME}' ({TELEGRAM_SESSION_NAME}) успешно запущен и слушает.")
        
        # Основной цикл работы
        await client.run_until_disconnected()

    except (AuthKeyError, UnauthorizedError, UserDeactivatedError, SessionExpiredError) as e_auth:
        logger.critical(f"Критическая ошибка авторизации '{TELEGRAM_SESSION_NAME}': {e_auth}. Сессия невалидна или аккаунт удален/неактивен. Удалите volume сессии и перезапустите контейнер для новой авторизации.", exc_info=True)
        # Важно: просто перезапуск контейнера не поможет, если volume с невалидной сессией остался.
        # Нужно удалить volume (через `docker volume rm ...`) или передать новую строку сессии.
    except asyncio.CancelledError:
        logger.info(f"Работа агента '{TELEGRAM_SESSION_NAME}' отменена.")
    except ConnectionRefusedError:
        logger.critical(f"Не удалось подключиться к Telegram для '{TELEGRAM_SESSION_NAME}'. Проверьте сеть.")
    except Exception as e:
        logger.critical(f"Критическая ошибка в `actual_agent_work` для '{TELEGRAM_SESSION_NAME}': {e}", exc_info=True)
    finally:
        # Корректное отключение клиента
        if client and client.is_connected():
            logger.info(f"Отключение Telethon клиента '{TELEGRAM_SESSION_NAME}'...")
            try: await client.disconnect()
            except Exception as e_dc: logger.warning(f"Ошибка при отключении клиента: {e_dc}")
        logger.info(f"Telethon клиент '{TELEGRAM_SESSION_NAME}' остановлен.")


# --- Точка входа при запуске скрипта ---
if __name__ == '__main__':
    # Установка имени бота перед запуском
    if BOT_NAME_FROM_ENV: BOT_TELEGRAM_NAME = BOT_NAME_FROM_ENV
    elif not BOT_TELEGRAM_NAME : BOT_TELEGRAM_NAME = f"HR Ассистент ({TELEGRAM_SESSION_NAME})"

    logger.info(f"Запуск экземпляра агента '{TELEGRAM_SESSION_NAME}' с именем '{BOT_TELEGRAM_NAME}'...")
    try:
        # Запуск основного асинхронного цикла
        asyncio.run(actual_agent_work())
    except KeyboardInterrupt:
        logger.info(f"Получен сигнал Ctrl+C для '{TELEGRAM_SESSION_NAME}', остановка...")
    except Exception as e_main_run:
        logger.critical(f"Неперехваченная ошибка в main '{TELEGRAM_SESSION_NAME}': {e_main_run}", exc_info=True)
    finally:
        logger.info(f"Процесс агента '{TELEGRAM_SESSION_NAME}' завершен.")