# hr_bots_project/admin_bot/admin_bot.py

import logging
import os
import json
import docker # Для управления Docker контейнерами
from typing import Dict, Any
import asyncio # Для await asyncio.sleep
import redis # <--- Для работы admin_bot с Redis

from dotenv import load_dotenv
# Импорты PTB (python-telegram-bot)
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
    ConversationHandler,
    CallbackQueryHandler
)
from telegram.constants import ParseMode

# --- Загрузка переменных окружения ---
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path)
    print(f"Загружен .env файл для admin_bot: {dotenv_path}")
else:
    print(f"Предупреждение: .env файл для admin_bot не найден по пути {dotenv_path}.")

# --- Конфигурация из переменных окружения ---
ADMIN_BOT_TOKEN = os.getenv('ADMIN_BOT_TOKEN')
ADMIN_USER_IDS_STR = os.getenv('ADMIN_USER_IDS')
LOG_LEVEL_STR = os.getenv('LOG_LEVEL', 'INFO').upper()
DOCKER_IMAGE_NAME = os.getenv('DOCKER_AGENT_IMAGE_NAME', 'hr_agent_image:latest')
GEMINI_API_KEY_FOR_AGENTS = os.getenv('GEMINI_API_KEY_FOR_AGENTS')
GEMINI_MODEL_NAME_FOR_AGENTS = os.getenv('GEMINI_MODEL_NAME_FOR_AGENTS', 'gemini-1.5-flash-latest')
AGENT_LOG_LEVEL = os.getenv('AGENT_LOG_LEVEL', 'INFO')

# --- Конфигурация для Redis (для admin_bot и для передачи агентам) ---
REDIS_HOST = os.getenv('REDIS_HOST', 'redis') # Имя сервиса Redis в Docker Compose
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
REDIS_AGENTS_CONFIG_KEY = os.getenv('REDIS_AGENTS_CONFIG_KEY', 'hr_bots:agents_config') # Ключ в Redis для хранения конфига

# Имя сети Docker, к которой будут подключаться агенты.
DOCKER_AGENT_NETWORK_NAME = os.getenv('DOCKER_AGENT_NETWORK_NAME', 'hr_bots_project_hr_bots_internal_network')


# --- Настройка логирования ---
numeric_log_level = getattr(logging, LOG_LEVEL_STR, logging.INFO)
logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=numeric_log_level)
logger = logging.getLogger("AdminBot")
logger.info(f"Уровень логирования Управляющего бота: {LOG_LEVEL_STR}")


# --- Инициализация клиента Redis для Admin Bot ---
admin_redis_client = None
try:
    admin_redis_client = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=True) # decode_responses=True для удобства работы со строками
    admin_redis_client.ping()
    logger.info(f"AdminBot: Успешное подключение к Redis: {REDIS_HOST}:{REDIS_PORT}")
except redis.exceptions.ConnectionError as e:
    logger.critical(f"AdminBot: Критическая ошибка - не удалось подключиться к Redis ({REDIS_HOST}:{REDIS_PORT}): {e}. Конфигурация агентов не будет доступна.", exc_info=True)
    admin_redis_client = None # Устанавливаем в None, если подключение не удалось
    # exit(1) # Раскомментируйте, если admin_bot не может работать без Redis


# --- Загрузка и обработка DNS-серверов для агентов ---
AGENT_DNS_SERVERS_STR = os.getenv('AGENT_DNS_SERVERS')
AGENT_DNS_LIST = []
if AGENT_DNS_SERVERS_STR:
    try:
        AGENT_DNS_LIST = [s.strip() for s in AGENT_DNS_SERVERS_STR.split(',') if s.strip()]
        if AGENT_DNS_LIST:
            logger.info(f"Для запускаемых агентов будут использованы следующие DNS-серверы: {AGENT_DNS_LIST}")
        else:
            logger.info("AGENT_DNS_SERVERS указаны, но строка пуста. Будут использованы DNS по умолчанию Docker хоста.")
    except Exception as e:
        logger.warning(f"Не удалось разобрать AGENT_DNS_SERVERS ('{AGENT_DNS_SERVERS_STR}'): {e}. Будут использованы DNS по умолчанию.")
        AGENT_DNS_LIST = []
else:
    logger.info("AGENT_DNS_SERVERS не установлены. Будут использованы DNS по умолчанию Docker хоста.")


# --- Проверки критичных переменных (после инициализации логгера) ---
if not ADMIN_BOT_TOKEN: logger.critical("Критическая ошибка: ADMIN_BOT_TOKEN не установлен."); exit(1)
if not ADMIN_USER_IDS_STR: logger.critical("Критическая ошибка: ADMIN_USER_IDS не установлен."); exit(1)
if not DOCKER_IMAGE_NAME: logger.critical("Критическая ошибка: DOCKER_AGENT_IMAGE_NAME не установлен."); exit(1)
if not GEMINI_API_KEY_FOR_AGENTS: logger.critical("Критическая ошибка: GEMINI_API_KEY_FOR_AGENTS не установлен."); exit(1)
if not admin_redis_client: logger.critical("Критическая ошибка: Клиент Redis для AdminBot не инициализирован. Проверьте соединение с Redis."); exit(1)


try:
    ADMIN_USER_IDS = [int(admin_id.strip()) for admin_id in ADMIN_USER_IDS_STR.split(',')]
except ValueError:
    logger.critical(f"Критическая ошибка: ADMIN_USER_IDS ({ADMIN_USER_IDS_STR}) содержит нечисловое значение.")
    exit(1)

# --- Инициализация Docker клиента ---
DOCKER_CLIENT = None
try:
    DOCKER_CLIENT = docker.from_env()
    DOCKER_CLIENT.ping() # Проверка доступности Docker API
    logger.info("Docker клиент успешно инициализирован.")
except docker.errors.DockerException as e:
    logger.error(f"Критическая ошибка: Не удалось подключиться к Docker Engine: {e}")
    logger.error("Убедитесь, что Docker запущен, API доступен и у пользователя есть права.")
    DOCKER_CLIENT = None

# --- Вспомогательные функции для работы с конфигурацией Агентов в Redis ---
def save_agents_config(config: Dict[str, Dict[str, Any]]):
    """Сохраняет конфигурацию агентов в Redis."""
    if not admin_redis_client:
        logger.error("Ошибка сохранения конфигурации: Redis клиент не инициализирован.")
        return
    try:
        admin_redis_client.set(REDIS_AGENTS_CONFIG_KEY, json.dumps(config))
        logger.debug(f"Конфигурация агентов сохранена в Redis по ключу '{REDIS_AGENTS_CONFIG_KEY}'.")
    except redis.exceptions.RedisError as e:
        logger.error(f"Ошибка сохранения конфигурации в Redis: {e}")
    except TypeError as e_json: # Ошибка сериализации в JSON
        logger.error(f"Ошибка сериализации конфигурации агентов в JSON: {e_json}. Конфиг: {config}")


def load_agents_config() -> Dict[str, Dict[str, Any]]:
    """Загружает конфигурацию агентов из Redis."""
    if not admin_redis_client:
        logger.error("Ошибка загрузки конфигурации: Redis клиент не инициализирован. Возвращаю пустой конфиг.")
        return {}
    try:
        config_json = admin_redis_client.get(REDIS_AGENTS_CONFIG_KEY)
        if config_json is None:
            logger.info(f"Конфигурация агентов не найдена в Redis по ключу '{REDIS_AGENTS_CONFIG_KEY}'. Создаю пустую.")
            save_agents_config({}) # Создаем пустую конфигурацию в Redis
            return {}
        config = json.loads(config_json)
        if not isinstance(config, dict):
            logger.error(f"Данные в Redis по ключу '{REDIS_AGENTS_CONFIG_KEY}' не являются словарем. Возвращаю пустой конфиг.")
            return {}
        return config
    except redis.exceptions.RedisError as e:
        logger.error(f"Ошибка загрузки конфигурации из Redis: {e}. Возвращаю пустой конфиг.")
        return {}
    except json.JSONDecodeError:
        logger.error(f"Ошибка декодирования JSON из Redis (ключ '{REDIS_AGENTS_CONFIG_KEY}'). Возвращаю пустой конфиг.")
        # Можно попробовать удалить некорректный ключ или сохранить пустой конфиг
        # admin_redis_client.delete(REDIS_AGENTS_CONFIG_KEY)
        # save_agents_config({})
        return {}

def update_agent_status_in_config_file(session_name: str, status_message: str, is_active: bool = None):
    """Обновляет статус конкретного агента в конфигурации в Redis."""
    agents = load_agents_config() # Загружаем из Redis
    if session_name in agents:
        agents[session_name]["status_message"] = status_message
        if is_active is not None:
            agents[session_name]["is_active"] = is_active
        save_agents_config(agents) # Сохраняем обратно в Redis
    else:
        logger.warning(f"Попытка обновить статус в Redis для несуществующего агента: {session_name}")

# --- Декоратор для проверки прав администратора ---
def restricted(func):
    """Декоратор для ограничения доступа к обработчикам только для администраторов."""
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        if user_id not in ADMIN_USER_IDS:
            logger.warning(f"Неавторизованный доступ от user_id: {user_id} к функции {func.__name__}")
            reply_text = "У вас нет прав для выполнения этого действия."
            if update.callback_query:
                await update.callback_query.answer(reply_text, show_alert=True)
            elif update.message:
                await update.message.reply_text(reply_text)
            return

        if not admin_redis_client:
            err_msg = "Действие невозможно: AdminBot не подключен к Redis."
            logger.error(err_msg + f" (Попытка вызова {func.__name__})")
            if update.callback_query: await update.callback_query.answer(err_msg, show_alert=True)
            elif update.message: await update.message.reply_text(err_msg)
            return

        if hasattr(func, '_requires_docker') and func._requires_docker and not DOCKER_CLIENT:
             err_msg = "Действие невозможно: Docker клиент не инициализирован или недоступен."
             logger.error(err_msg + f" (Попытка вызова {func.__name__})")
             if update.callback_query:
                 await update.callback_query.answer(err_msg, show_alert=True)
             elif update.message:
                 await update.message.reply_text(err_msg)
             return

        return await func(update, context, *args, **kwargs)
    return wrapped

def requires_docker(func):
    """Маркирует функцию, требующую Docker клиента."""
    func._requires_docker = True
    return func

# --- Константы для Callback Data ---
ACTION_PREFIX_VIEW_AGENT = "view_agent_"
ACTION_PREFIX_TOGGLE_AGENT = "toggle_agent_"
ACTION_PREFIX_CONFIRM_DELETE_AGENT = "confirm_del_agent_"
ACTION_PREFIX_DO_DELETE_AGENT = "do_del_agent_"
ACTION_PREFIX_AGENT_LOGS = "logs_agent_"
ACTION_BACK_TO_LIST = "back_to_list"
ACTION_MAIN_MENU = "main_menu"
ACTION_ADD_AGENT_CONV_START = "add_agent_conv"

# --- Функции для работы с Docker-контейнерами ---
def get_container_name(session_name: str) -> str:
    """Генерирует безопасное имя для Docker контейнера."""
    safe_session_name = "".join(c if c.isalnum() else '_' for c in session_name)
    return f"hr_agent_container_{safe_session_name.lower()}"

def get_container_status_message(container_name: str) -> str:
    """Получает статус Docker контейнера."""
    if not DOCKER_CLIENT: return "Docker клиент недоступен"
    try:
        container = DOCKER_CLIENT.containers.get(container_name)
        return f"Docker: {container.status}"
    except docker.errors.NotFound:
        return "Docker: Контейнер не найден"
    except Exception as e:
        logger.error(f"Ошибка получения статуса контейнера {container_name}: {e}")
        return "Docker: Ошибка статуса"

@requires_docker
async def start_agent_container(session_name: str, agent_config: Dict[str, Any], context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Запускает или перезапускает Docker контейнер для агента."""
    container_name = get_container_name(session_name)

    try:
        existing_container = DOCKER_CLIENT.containers.get(container_name)
        if existing_container.status == 'running':
            logger.info(f"Контейнер {container_name} ({session_name}) уже запущен.")
            update_agent_status_in_config_file(session_name, get_container_status_message(container_name), is_active=True)
            return True
        else:
            logger.info(f"Контейнер {container_name} существует (статус: {existing_container.status}). Удаление перед перезапуском...")
            try:
                existing_container.remove(force=True)
                logger.info(f"Существующий контейнер {container_name} успешно удален.")
            except docker.errors.APIError as e_remove:
                logger.error(f"Не удалось удалить существующий контейнер {container_name}: {e_remove}.")
    except docker.errors.NotFound:
        logger.info(f"Контейнер {container_name} не найден. Будет создан новый.")
    except Exception as e_check:
        logger.error(f"Ошибка при проверке существующего контейнера {container_name}: {e_check}", exc_info=True)
        update_agent_status_in_config_file(session_name, f"Ошибка Docker: {str(e_check)[:50]}", is_active=False)
        return False

    env_vars = {
        "TELEGRAM_API_ID": str(agent_config["api_id"]),
        "TELEGRAM_API_HASH": agent_config["api_hash"],
        "TELEGRAM_SESSION_NAME": session_name,
        "GEMINI_API_KEY": GEMINI_API_KEY_FOR_AGENTS,
        "GEMINI_MODEL_NAME": GEMINI_MODEL_NAME_FOR_AGENTS,
        "LOG_LEVEL": AGENT_LOG_LEVEL,
        "REDIS_HOST": REDIS_HOST, # Используем тот же Redis, что и admin_bot
        "REDIS_PORT": str(REDIS_PORT),
    }
    if agent_config.get("session_string"):
        env_vars["TELEGRAM_SESSION_STRING"] = agent_config["session_string"]
    if agent_config.get("bot_name_override"):
        env_vars["BOT_NAME_OVERRIDE"] = agent_config["bot_name_override"]

    logger.info(f"Подготовка к запуску контейнера '{container_name}' из образа '{DOCKER_IMAGE_NAME}' для сессии {session_name}")

    run_parameters = {
        "image": DOCKER_IMAGE_NAME,
        "detach": True,
        "name": container_name,
        "environment": env_vars,
        "restart_policy": {"Name": "unless-stopped"}
    }

    volume_name = f"{container_name}_telethon_session"
    try:
        DOCKER_CLIENT.volumes.get(volume_name)
        logger.info(f"Docker volume '{volume_name}' уже существует.")
    except docker.errors.NotFound:
        DOCKER_CLIENT.volumes.create(name=volume_name)
        logger.info(f"Docker volume '{volume_name}' создан.")
    except Exception as e_vol_check:
        logger.error(f"Ошибка при проверке/создании volume '{volume_name}': {e_vol_check}.")
        update_agent_status_in_config_file(session_name, f"Ошибка Volume: {str(e_vol_check)[:50]}", is_active=False)
        return False
    run_parameters["volumes"] = {volume_name: {'bind': '/app/sessions', 'mode': 'rw'}}

    if AGENT_DNS_LIST:
        run_parameters["dns"] = AGENT_DNS_LIST
        logger.info(f"Для '{container_name}' установлены DNS: {AGENT_DNS_LIST}")
    else:
        logger.info(f"Для '{container_name}' DNS по умолчанию Docker хоста.")

    if DOCKER_AGENT_NETWORK_NAME:
        try:
            DOCKER_CLIENT.networks.get(DOCKER_AGENT_NETWORK_NAME)
            run_parameters["network"] = DOCKER_AGENT_NETWORK_NAME
            logger.info(f"Контейнер '{container_name}' будет в сети '{DOCKER_AGENT_NETWORK_NAME}'.")
        except docker.errors.NotFound:
            logger.warning(f"Сеть '{DOCKER_AGENT_NETWORK_NAME}' не найдена. Запуск в сети Docker по умолчанию.")
        except Exception as e_net_check:
            logger.error(f"Ошибка подключения к сети '{DOCKER_AGENT_NETWORK_NAME}': {e_net_check}. Запуск в сети Docker по умолчанию.")
    else:
        logger.info(f"DOCKER_AGENT_NETWORK_NAME не указана. Запуск в сети Docker по умолчанию.")

    try:
        log_run_params = {k: v for k, v in run_parameters.items() if k != "environment"}
        log_run_params["environment_keys"] = list(run_parameters.get("environment", {}).keys())
        logger.debug(f"Запуск контейнера '{container_name}' с параметрами: {log_run_params}")

        container = DOCKER_CLIENT.containers.run(**run_parameters)
        logger.info(f"Контейнер {container.short_id} ({container_name}) для {session_name} запущен.")
        await asyncio.sleep(2.5)

        try:
            current_container = DOCKER_CLIENT.containers.get(container_name)
            current_container_status = current_container.status
            is_active_status = (current_container_status == 'running')
            update_agent_status_in_config_file(session_name, f"Docker: {current_container_status}", is_active=is_active_status)
            if not is_active_status:
                 logger.warning(f"Контейнер {container_name} статус '{current_container_status}'. Проверьте логи.")
        except docker.errors.NotFound:
            logger.error(f"Контейнер {container_name} не найден после запуска.")
            update_agent_status_in_config_file(session_name, "Ошибка: Не найден после запуска", is_active=False)
            return False
        except Exception as e_status_check:
            logger.error(f"Ошибка статуса {container_name} после запуска: {e_status_check}")
            update_agent_status_in_config_file(session_name, f"Ошибка статуса: {str(e_status_check)[:50]}", is_active=False)
            return False
        return True
    except docker.errors.APIError as e_api:
        logger.error(f"Ошибка Docker API при запуске {session_name} ('{container_name}'): {e_api}", exc_info=True)
        update_agent_status_in_config_file(session_name, f"Ошибка Docker API: {str(e_api)[:100]}", is_active=False)
        return False
    except Exception as e_other_run:
        logger.error(f"Непредвиденная ошибка при запуске {session_name} ('{container_name}'): {e_other_run}", exc_info=True)
        update_agent_status_in_config_file(session_name, f"Ошибка запуска: {str(e_other_run)[:100]}", is_active=False)
        return False

@requires_docker
async def stop_agent_container(session_name: str, context: ContextTypes.DEFAULT_TYPE, remove_container_and_volume: bool = False) -> bool:
    """Останавливает и опционально удаляет Docker контейнер и его volume."""
    container_name = get_container_name(session_name)
    try:
        container = DOCKER_CLIENT.containers.get(container_name)
        logger.info(f"Остановка контейнера {container_name} ({session_name})...")
        container.stop(timeout=10)
        logger.info(f"Контейнер {container_name} ({session_name}) остановлен.")
        final_status_msg = get_container_status_message(container_name)

        if remove_container_and_volume:
            logger.info(f"Удаление остановленного контейнера {container_name}...")
            container.remove()
            logger.info(f"Контейнер {container_name} удален.")
            volume_name = f"{container_name}_telethon_session"
            try:
                volume = DOCKER_CLIENT.volumes.get(volume_name)
                volume.remove(force=True)
                logger.info(f"Docker volume '{volume_name}' удален.")
            except docker.errors.NotFound:
                logger.info(f"Docker volume '{volume_name}' не найден для удаления.")
            except Exception as ve:
                logger.error(f"Ошибка при удалении Docker volume '{volume_name}': {ve}")
            final_status_msg = "Остановлен и удален (Docker)"

        update_agent_status_in_config_file(session_name, final_status_msg, is_active=False)
        return True
    except docker.errors.NotFound:
        logger.warning(f"Контейнер {container_name} ({session_name}) не найден для остановки/удаления.")
        update_agent_status_in_config_file(session_name, "Не найден в Docker (при остановке)", is_active=False)
        return True
    except Exception as e:
        logger.error(f"Ошибка Docker при остановке/удалении {container_name} ({session_name}): {e}", exc_info=True)
        update_agent_status_in_config_file(session_name, f"Ошибка остановки Docker: {str(e)[:50]}", is_active=None)
        return False

# --- Функции для отображения меню ---
async def get_main_menu_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [InlineKeyboardButton("📋 Список HR-Агентов", callback_data=ACTION_BACK_TO_LIST)],
        [InlineKeyboardButton("➕ Добавить HR-Агента", callback_data=ACTION_ADD_AGENT_CONV_START)],
    ]
    return InlineKeyboardMarkup(keyboard)

@restricted
async def start_panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    logger.info(f"Пользователь {user.id} ({user.first_name}) открыл панель управления.")
    reply_markup = await get_main_menu_keyboard()
    text = f"👋 Привет, {user.first_name}! Панель управления HR-Агентами (Docker + Redis):"
    if update.callback_query and update.callback_query.data == ACTION_MAIN_MENU:
        try:
            await update.callback_query.edit_message_text(text=text, reply_markup=reply_markup)
        except Exception as e:
            logger.debug(f"Не удалось обновить сообщение для главного меню: {e}")
            await update.callback_query.answer()
    elif update.message:
         await update.message.reply_text(text, reply_markup=reply_markup)

@restricted
async def show_agents_list_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, edit_message: bool = True):
    query = update.callback_query
    message_to_handle = query.message if query else update.message
    if not message_to_handle:
        logger.warning("show_agents_list_menu вызван без сообщения.")
        return

    if query: await query.answer("Обновляю список агентов...")

    agents = load_agents_config() # Загрузка из Redis
    if DOCKER_CLIENT:
        statuses_changed = False
        for session_name, config_data in list(agents.items()):
            container_name = get_container_name(session_name)
            actual_docker_status_msg = get_container_status_message(container_name)
            is_running_in_docker = "running" in actual_docker_status_msg.lower()
            config_status_msg = config_data.get("status_message", "N/A")
            config_is_active = config_data.get("is_active", False)

            if config_status_msg != actual_docker_status_msg or config_is_active != is_running_in_docker:
                update_agent_status_in_config_file(session_name, actual_docker_status_msg, is_active=is_running_in_docker)
                statuses_changed = True
        if statuses_changed:
            agents = load_agents_config() # Перезагрузка из Redis
            logger.info("Статусы агентов в Redis синхронизированы с Docker.")

    keyboard = []
    if not agents:
        text = "Список HR-Агентов пуст."
    else:
        text = "📋 Список HR-Агентов (Docker + Redis):\n\n"
        for session_name, config in agents.items():
            is_active = config.get("is_active", False)
            status_message_brief = config.get("status_message", "N/A").replace("Docker: ", "")
            status_icon = "🟢" if is_active else \
                          ("🔴" if "не найден" not in status_message_brief.lower() and \
                                   "остановлен" not in status_message_brief.lower() and \
                                   "exited" not in status_message_brief.lower() else \
                           ("⚪️" if "не найден" in status_message_brief.lower() else "⚫️"))
            display_name = (session_name[:20] + '..') if len(session_name) > 22 else session_name
            keyboard.append([InlineKeyboardButton(f"{status_icon} {display_name} ({status_message_brief})", callback_data=f"{ACTION_PREFIX_VIEW_AGENT}{session_name}")])

    keyboard.append([InlineKeyboardButton("➕ Добавить HR-Агента", callback_data=ACTION_ADD_AGENT_CONV_START)])
    is_main_menu_context = (update.message and update.message.text in ["/start", "/panel"]) or \
                           (query and query.data == ACTION_MAIN_MENU)
    if not is_main_menu_context:
         keyboard.append([InlineKeyboardButton("🏠 В главное меню", callback_data=ACTION_MAIN_MENU)])
    reply_markup = InlineKeyboardMarkup(keyboard)

    try:
        if query and edit_message:
            await query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)
        elif update.message:
            await update.message.reply_text(text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)
        elif query and not edit_message:
            await context.bot.send_message(chat_id=query.message.chat_id, text=text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)
    except Exception as e:
        logger.warning(f"Не удалось обновить/отправить список агентов: {e}", exc_info=True)
        if query: await query.answer("Ошибка обновления списка.")

@restricted
async def show_agent_management_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, session_name: str):
    query = update.callback_query
    if not query:
        logger.warning("show_agent_management_menu вызван без callback_query.")
        return

    agents = load_agents_config() # Загрузка из Redis
    agent_config = agents.get(session_name)
    if not agent_config:
        await query.answer("Агент не найден в конфигурации.", show_alert=True)
        await show_agents_list_menu(update, context)
        return

    container_name = get_container_name(session_name)
    actual_docker_status_msg = get_container_status_message(container_name)
    is_active_in_docker = "running" in actual_docker_status_msg.lower()

    if agent_config.get("status_message") != actual_docker_status_msg or \
       agent_config.get("is_active") != is_active_in_docker:
        update_agent_status_in_config_file(session_name, actual_docker_status_msg, is_active=is_active_in_docker)
        agent_config = load_agents_config().get(session_name) # Перечитать из Redis
        if not agent_config:
            await query.answer("Агент был удален.", show_alert=True)
            await show_agents_list_menu(update, context); return

    is_active = agent_config.get("is_active", False)
    status_message_brief = agent_config.get("status_message", "N/A").replace("Docker: ", "")
    status_icon = "🟢" if is_active else \
                  ("🔴" if "не найден" not in status_message_brief.lower() and \
                           "остановлен" not in status_message_brief.lower() and \
                           "exited" not in status_message_brief.lower() else \
                   ("⚪️" if "не найден" in status_message_brief.lower() else "⚫️"))

    text = f"🛠️ Управление агентом: `{session_name}`\n"
    text += f"Статус: {status_icon} *{status_message_brief}*\n"
    text += f"API ID: `{agent_config.get('api_id', 'N/A')}`\n"
    bot_name = agent_config.get('bot_name_override', 'Имя из профиля Telegram')
    text += f"Имя в чатах: `{bot_name}`\n"
    session_info = "`Присутствует`" if agent_config.get('session_string') else "`Отсутствует`"
    text += f"Строка сессии: {session_info}\n"

    keyboard_buttons = [
        [InlineKeyboardButton(f"{'Стоп ⏹️' if is_active else 'Старт ▶️'} Агента", callback_data=f"{ACTION_PREFIX_TOGGLE_AGENT}{session_name}")],
        [InlineKeyboardButton(f"📋 Логи Агента (tail=20)", callback_data=f"{ACTION_PREFIX_AGENT_LOGS}{session_name}")],
        [InlineKeyboardButton(f"🗑️ Удалить Агента", callback_data=f"{ACTION_PREFIX_CONFIRM_DELETE_AGENT}{session_name}")],
        [InlineKeyboardButton("⬅️ К списку агентов", callback_data=ACTION_BACK_TO_LIST)]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard_buttons)

    try:
        await query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)
    except Exception as e:
        logger.debug(f"Не удалось обновить меню управления агентом {session_name}: {e}")
        await query.answer()

# --- Обработчик CallbackQuery ---
@restricted
async def button_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user = query.from_user
    logger.info(f"Нажата кнопка: '{data}' пользователем {user.id} ({user.first_name})")

    if data == ACTION_BACK_TO_LIST:
        await show_agents_list_menu(update, context)
    elif data == ACTION_MAIN_MENU:
        await start_panel_command(update, context)
    elif data == ACTION_ADD_AGENT_CONV_START:
        if not DOCKER_CLIENT:
            await query.message.reply_text("Действие невозможно: Docker клиент не инициализирован.")
            return
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="Для добавления HR-Агента, отправьте команду /add_agent\n\nОтмена: /cancel."
        )
    elif data.startswith(ACTION_PREFIX_VIEW_AGENT):
        session_name = data[len(ACTION_PREFIX_VIEW_AGENT):]
        await show_agent_management_menu(update, context, session_name)
    elif data.startswith(ACTION_PREFIX_TOGGLE_AGENT):
        session_name = data[len(ACTION_PREFIX_TOGGLE_AGENT):]
        agents = load_agents_config() # Загрузка из Redis
        if session_name in agents:
            agent_conf = agents[session_name]
            should_start = not agent_conf.get("is_active", False)
            action_text = "Запуск" if should_start else "Остановка"
            await query.edit_message_text(text=f"{action_text} агента `{session_name}`...", parse_mode=ParseMode.MARKDOWN)
            action_func = start_agent_container if should_start else stop_agent_container
            func_args = (session_name, agent_conf, context) if should_start else (session_name, context)
            action_result = await action_func(*func_args)
            await query.answer(
                f"{action_text} агента {session_name} {'успешно' if action_result else 'не удался'}.",
                show_alert=not action_result
            )
            await asyncio.sleep(0.5)
            await show_agent_management_menu(update, context, session_name)
        else:
            await query.answer("Агент не найден в конфигурации!", show_alert=True)
            await show_agents_list_menu(update, context)
    elif data.startswith(ACTION_PREFIX_CONFIRM_DELETE_AGENT):
        session_name = data[len(ACTION_PREFIX_CONFIRM_DELETE_AGENT):]
        keyboard = [
            [InlineKeyboardButton(f"✅ Да, удалить '{session_name[:15]}..'", callback_data=f"{ACTION_PREFIX_DO_DELETE_AGENT}{session_name}")],
            [InlineKeyboardButton("❌ Отмена", callback_data=f"{ACTION_PREFIX_VIEW_AGENT}{session_name}")]
        ]
        await query.edit_message_text(
            text=f"Уверены, что хотите удалить агента `{session_name}`?\nУдаление конфигурации, Docker-контейнера и volume сессии.",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    elif data.startswith(ACTION_PREFIX_DO_DELETE_AGENT):
        session_name = data[len(ACTION_PREFIX_DO_DELETE_AGENT):]
        agents_cfg = load_agents_config() # Загрузка из Redis
        if session_name in agents_cfg:
            logger.info(f"Удаление агента {session_name} админом {user.id}...")
            await query.edit_message_text(text=f"Удаление агента `{session_name}` (контейнер, volume, конфиг из Redis)...", parse_mode=ParseMode.MARKDOWN)
            stopped_removed_ok = await stop_agent_container(session_name, context, remove_container_and_volume=True)
            if not stopped_removed_ok:
                logger.warning(f"Ошибки при удалении Docker-ресурсов для {session_name}, но конфиг из Redis будет удален.")
                await query.answer("Ошибки при удалении Docker-ресурсов, конфиг из Redis удален.", show_alert=True)
            else:
                await query.answer(f"Docker-ресурсы для {session_name} удалены.")

            del agents_cfg[session_name]
            save_agents_config(agents_cfg) # Сохранение в Redis
            logger.info(f"Агент {session_name} удален из конфигурации в Redis.")
            await asyncio.sleep(0.5)
            await show_agents_list_menu(update, context)
        else:
            await query.answer("Агент уже удален или не найден в конфигурации.", show_alert=True)
            await show_agents_list_menu(update, context)
    elif data.startswith(ACTION_PREFIX_AGENT_LOGS):
         session_name = data[len(ACTION_PREFIX_AGENT_LOGS):]
         container_name = get_container_name(session_name)
         log_text = f"Логи для `{session_name}` (контейнер: `{container_name}`):\n"
         if DOCKER_CLIENT:
             try:
                 container = DOCKER_CLIENT.containers.get(container_name)
                 logs = container.logs(tail=20).decode('utf-8', errors='replace')
                 log_text += f"```text\n{logs or '(Логи пусты / контейнер неактивен)'}\n```"
             except docker.errors.NotFound:
                 log_text += "_Контейнер не найден в Docker._"
             except Exception as e_logs:
                 log_text += f"_Ошибка получения логов: {e_logs}_"
         else:
             log_text += "_Docker клиент недоступен._"
         await query.message.reply_text(log_text, parse_mode=ParseMode.MARKDOWN)
         await query.answer("Логи отправлены.")

# --- Логика добавления Агента (ConversationHandler) ---
(ASK_SESSION_NAME, ASK_API_ID, ASK_API_HASH, ASK_SESSION_STRING, ASK_BOT_NAME) = map(chr, range(5))

@restricted
async def add_agent_command_entry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    if not DOCKER_CLIENT:
        await update.message.reply_text("Не могу добавить агента: Docker клиент не инициализирован.")
        return ConversationHandler.END
    await update.message.reply_text(
        "Добавление HR-Агента.\n\n"
        "Шаг 1: **Уникальное имя сессии** (латиница, цифры, `_`, начинается с буквы).\n\n"
        "Отмена: /cancel."
    , parse_mode=ParseMode.MARKDOWN)
    return ASK_SESSION_NAME

async def received_session_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    session_name_input = update.message.text.strip()
    if not session_name_input or not session_name_input[0].isalpha() or not all(c.isalnum() or c == '_' for c in session_name_input):
        await update.message.reply_text(
            "⚠️ Некорректное имя сессии. Начинается с буквы, только латиница, цифры, '_'.\n"
            "Введите имя еще раз или /cancel."
        )
        return ASK_SESSION_NAME
    agents = load_agents_config() # Загрузка из Redis
    if session_name_input in agents:
        await update.message.reply_text(
            f"⚠️ Агент '{session_name_input}' уже существует. Другое имя или /cancel."
        )
        return ASK_SESSION_NAME
    context.user_data['new_agent_session_name'] = session_name_input
    await update.message.reply_text(
        f"✅ Имя сессии: `{session_name_input}`\n\n"
        "Шаг 2: **API ID** (число с my.telegram.org).\n\n/cancel."
    , parse_mode=ParseMode.MARKDOWN)
    return ASK_API_ID

async def received_api_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    try:
        api_id_input = int(update.message.text.strip())
        if api_id_input <= 0: raise ValueError("API ID < 0")
        context.user_data['new_agent_api_id'] = api_id_input
        await update.message.reply_text(
            f"✅ API ID: `{api_id_input}`\n\n"
            "Шаг 3: **API HASH** (строка, ~32 hex с my.telegram.org).\n\n/cancel."
        , parse_mode=ParseMode.MARKDOWN)
        return ASK_API_HASH
    except ValueError as e:
        await update.message.reply_text(f"⚠️ API ID - целое положительное число. Ошибка: {e}\nЕще раз или /cancel.")
        return ASK_API_ID

async def received_api_hash(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    api_hash_input = update.message.text.strip()
    if not api_hash_input or len(api_hash_input) < 30 or not all(c in '0123456789abcdefABCDEF' for c in api_hash_input):
        await update.message.reply_text(
            "⚠️ API HASH некорректен (~32 hex символа).\nЕще раз или /cancel."
        )
        return ASK_API_HASH
    context.user_data['new_agent_api_hash'] = api_hash_input
    await update.message.reply_text(
        f"✅ API HASH получен.\n\n"
        "Шаг 4: **Строка сессии Telethon** (Обязательно! Получить спец. ботом/скриптом).\n\n/cancel."
    , parse_mode=ParseMode.MARKDOWN)
    return ASK_SESSION_STRING

async def received_session_string(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    session_string_input = update.message.text.strip()
    if not session_string_input or len(session_string_input) < 50:
        await update.message.reply_text(
            "⚠️ Строка сессии короткая/пустая. Обязательное поле.\nВведите корректную строку или /cancel."
        )
        return ASK_SESSION_STRING
    logger.info(f"Получена строка сессии (хвост): ...{session_string_input[-10:]}")
    context.user_data['new_agent_session_string'] = session_string_input
    await update.message.reply_text(
        "✅ Строка сессии получена.\n\n"
        "Шаг 5: **Имя для агента в чатах** (например, 'Ольга, HR').\n"
        "Для имени из профиля Telegram отправьте тире (`-`) или `пропустить`.\n\n/cancel."
    , parse_mode=ParseMode.MARKDOWN)
    return ASK_BOT_NAME

async def received_bot_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    bot_name_input = update.message.text.strip()
    bot_name_override = None
    if bot_name_input.lower() not in ['-', 'пропустить', 'skip', 'none', '']:
        bot_name_override = bot_name_input
        logger.info(f"Имя для нового агента: '{bot_name_override}'")
    else:
        logger.info("Имя для нового агента: из профиля Telegram.")

    session_name = context.user_data.get('new_agent_session_name')
    api_id = context.user_data.get('new_agent_api_id')
    api_hash = context.user_data.get('new_agent_api_hash')
    session_string = context.user_data.get('new_agent_session_string')

    if not all([session_name, api_id, api_hash, session_string]):
        await update.message.reply_text("⚠️ Ошибка: не все данные собраны. Начните заново: /add_agent.")
        context.user_data.clear()
        return ConversationHandler.END

    agents = load_agents_config() # Загрузка из Redis
    new_agent_data = {
        "api_id": api_id, "api_hash": api_hash, "session_string": session_string,
        "bot_name_override": bot_name_override, "is_active": False,
        "status_message": "Добавлен, ожидает запуска"
    }
    agents[session_name] = new_agent_data
    save_agents_config(agents) # Сохранение в Redis

    name_display = f"`{bot_name_override}`" if bot_name_override else "имя из профиля Telegram"
    await update.message.reply_text(
        f"✅ HR-Агент `{session_name}` успешно добавлен!\n"
        f"Имя в чатах: {name_display}.\nСтатус: Ожидает запуска.\n\nУправление из списка агентов.",
        parse_mode=ParseMode.MARKDOWN
    )
    context.user_data.clear()
    await show_agents_list_menu(update, context, edit_message=False)
    return ConversationHandler.END

async def cancel_add_agent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("Добавление HR-Агента отменено.")
    context.user_data.clear()
    return ConversationHandler.END

# --- Точка входа ---
def main() -> None:
    if not admin_redis_client:
        logger.critical("Критическая ошибка: AdminBot не может запуститься без Redis. Проверьте конфигурацию и доступность Redis.")
        return
    if not DOCKER_CLIENT:
        logger.critical("Критическая ошибка: Docker клиент не инициализирован. Управляющий бот не может быть запущен.")
        return

    application = Application.builder().token(ADMIN_BOT_TOKEN).build()

    add_agent_conv_handler = ConversationHandler(
        entry_points=[CommandHandler('add_agent', add_agent_command_entry)],
        states={
            ASK_SESSION_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_session_name)],
            ASK_API_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_id)],
            ASK_API_HASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_hash)],
            ASK_SESSION_STRING: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_session_string)],
            ASK_BOT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, received_bot_name)],
        },
        fallbacks=[CommandHandler('cancel', cancel_add_agent)],
        conversation_timeout=15 * 60
    )

    application.add_handler(CommandHandler(["start", "panel"], start_panel_command))
    application.add_handler(CommandHandler("list_agents", lambda u,c: show_agents_list_menu(u, c, edit_message=False)))
    application.add_handler(add_agent_conv_handler)
    application.add_handler(CallbackQueryHandler(button_callback_handler))

    logger.info(f"Управляющий бот (Docker + Redis) запущен. Образ агентов: {DOCKER_IMAGE_NAME}")
    logger.info(f"Redis для AdminBot и агентов: Host='{REDIS_HOST}', Port='{REDIS_PORT}'")
    logger.info(f"Ключ конфига агентов в Redis: '{REDIS_AGENTS_CONFIG_KEY}'")
    logger.info(f"Сеть Docker для агентов: '{DOCKER_AGENT_NETWORK_NAME}'")

    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()