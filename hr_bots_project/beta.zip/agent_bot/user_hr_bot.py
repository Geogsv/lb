# hr_bots_project/agent_bot/user_hr_bot.py
import asyncio
import logging
import os
import random
import json
from datetime import datetime, timezone # Добавлен timezone

import redis # <-- Добавлено для Redis

from dotenv import load_dotenv # Для локального тестирования
from telethon import TelegramClient, events
from telethon.sessions import StringSession # Будем использовать StringSession или FileSession
from telethon.errors import (
    UserNotParticipantError, ChannelPrivateError, ChatWriteForbiddenError,
    UserIsBlockedError, FloodWaitError, AuthKeyError, UnauthorizedError, UserDeactivatedError, SessionExpiredError
)
import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold # Для safety_settings

# --- Загрузка переменных окружения (для локального запуска) ---
LOCAL_DEV_ENV_PATH = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(LOCAL_DEV_ENV_PATH):
    load_dotenv(LOCAL_DEV_ENV_PATH)
    # Используем имя сессии из ENV для логгера даже при локальном запуске
    session_name_for_log = os.getenv('TELEGRAM_SESSION_NAME', 'local_unknown')
    print(f"[Agent {session_name_for_log}] Загружен локальный .env файл: {LOCAL_DEV_ENV_PATH}")
else:
    session_name_for_log = os.getenv('TELEGRAM_SESSION_NAME', 'docker_unknown')


# --- Чтение конфигурации из переменных окружения ---
try:
    TELEGRAM_API_ID = int(os.getenv('TELEGRAM_API_ID'))
    TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
    # Имя сессии используется для файла сессии и для логгера
    TELEGRAM_SESSION_NAME = os.getenv('TELEGRAM_SESSION_NAME')
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')

    # Опциональные переменные
    TELEGRAM_SESSION_STRING = os.getenv('TELEGRAM_SESSION_STRING') # Строка сессии от админ-бота
    GEMINI_MODEL_NAME = os.getenv('GEMINI_MODEL_NAME', 'gemini-1.5-flash-latest')
    BOT_NAME_FROM_ENV = os.getenv('BOT_NAME_OVERRIDE') # Имя, заданное админом
    AGENT_LOG_LEVEL_STR = os.getenv('LOG_LEVEL', 'INFO').upper()

    # Redis конфигурация
    REDIS_HOST = os.getenv('REDIS_HOST', 'localhost') # 'redis' когда в Docker Compose
    REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
    USER_STATE_TTL_SECONDS = int(os.getenv('USER_STATE_TTL_SECONDS', 7 * 24 * 60 * 60)) # 7 дней TTL

except TypeError:
    # Логгер еще не настроен, используем print
    print(f"Критическая ошибка [Agent {TELEGRAM_SESSION_NAME or 'Unknown'}]: TELEGRAM_API_ID не число.")
    exit(1)
except ValueError:
    print(f"Критическая ошибка [Agent {TELEGRAM_SESSION_NAME or 'Unknown'}]: Неверный формат REDIS_PORT или USER_STATE_TTL_SECONDS.")
    exit(1)


# Проверка обязательных переменных
missing_vars_list = [var for var, val in {"TELEGRAM_API_ID": TELEGRAM_API_ID, "TELEGRAM_API_HASH": TELEGRAM_API_HASH,"TELEGRAM_SESSION_NAME": TELEGRAM_SESSION_NAME,"GEMINI_API_KEY": GEMINI_API_KEY}.items() if not val]
if missing_vars_list:
    print(f"Критическая ошибка [Agent {TELEGRAM_SESSION_NAME or 'Unknown'}]: Переменные не установлены: {', '.join(missing_vars_list)}")
    exit(1)

# --- Настройка логирования Агента ---
agent_numeric_log_level = getattr(logging, AGENT_LOG_LEVEL_STR, logging.INFO)
# Создаем логгер с именем сессии
logger = logging.getLogger(f"Agent_{TELEGRAM_SESSION_NAME}")
logger.setLevel(agent_numeric_log_level)
# Настраиваем обработчик и форматтер, только если логгер еще не настроен
if not logger.hasHandlers():
    log_formatter = logging.Formatter(f'[%(levelname)5s/%(asctime)s] %(name)s: %(message)s')
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(log_formatter)
    logger.addHandler(stream_handler)
    logger.propagate = False # Избегаем дублирования с root логгером
logger.info(f"Уровень логирования агента установлен на: {AGENT_LOG_LEVEL_STR}")


# --- Инициализация клиента Redis ---
redis_client = None
try:
    redis_client = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=False) # decode_responses=False, т.к. будем хранить json bytes
    redis_client.ping()
    logger.info(f"Успешное подключение к Redis: {REDIS_HOST}:{REDIS_PORT}")
except redis.exceptions.ConnectionError as e:
    logger.critical(f"Критическая ошибка: Не удалось подключиться к Redis ({REDIS_HOST}:{REDIS_PORT}): {e}", exc_info=True)
    redis_client = None # Устанавливаем в None, если подключение не удалось
    # В Docker-окружении агент должен иметь доступ к Redis, иначе его работа бессмысленна, если он на него полагается.
    # Можно добавить exit(1) здесь, если Redis критичен.
    # exit(1) # Раскомментируйте, если агент не может работать без Redis


# --- Глобальные переменные Агента ---
BOT_TELEGRAM_NAME = BOT_NAME_FROM_ENV # Начальное значение
client: TelegramClient = None

# --- Конфигурация Gemini ---
try:
    genai.configure(api_key=GEMINI_API_KEY)
    gemini_model = genai.GenerativeModel(GEMINI_MODEL_NAME)
    logger.info(f"Модель Gemini '{GEMINI_MODEL_NAME}' инициализирована.")
except Exception as e:
    logger.critical(f"Критическая ошибка инициализации Gemini: {e}", exc_info=True)
    exit(1) # Выход, если Gemini не работает

# --- СЦЕНАРИЙ И ПРОМПТЫ ДЛЯ HR-БОТА ---
RECRUITMENT_CONTEXT = "кандидат обратился по поводу открытой вакансии или с интересом к работе в компании"
IMPROVED_SYSTEM_PROMPT_TEMPLATE = f"""\
Ты — {{bot_name}}, дружелюбный и профессиональный ассистент по подбору персонала. Твоя главная задача — мягко провести первичное анкетирование кандидата, который обратился по поводу работы, и затем поддерживать с ним контакт ("держать теплым"), сообщая о дальнейших шагах и ссылаясь на текущую загруженность команды рекрутеров.
Твоя речь должна быть естественной, вежливой и располагающей. Используй смайлики уместно (например, 😊, 👍, 😉).
Задавай вопросы анкеты по одному. Внимательно читай ответы кандидата и обязательно реагируй на них перед тем, как задать следующий вопрос или перейти к следующему этапу.
Если кандидат спрашивает о деталях вакансии, на которые ты не можешь ответить, или задает сложные вопросы, мягко сообщи, что эту информацию ему предоставит рекрутер при личном общении, а твоя задача — собрать первичные данные для ускорения процесса. Пример ответа: "Это отличный вопрос! Детали по условиям и задачам лучше обсудить напрямую с рекрутером, который сможет дать самую точную информацию. Я пока соберу основные данные, чтобы ускорить наше знакомство, хорошо? 😊"
После завершения анкеты твоя задача — "подогревать" кандидата: вежливо сообщить, что его данные переданы, и рекрутер свяжется с ним в ближайшее возможное время. Упомяни, что сейчас у команды высокая загрузка, но его кандидатура очень важна. Пример ответа: "Спасибо большое за ответы! Я передал(а) всю информацию нашим рекрутерам. Сейчас у нас довольно много обращений, но мы обязательно рассмотрим вашу кандидатуру и свяжемся с вами, как только появится возможность. Ценим ваше терпение! 👍"
Если кандидат пишет тебе снова до того, как с ним связался рекрутер, еще раз поблагодари за терпение, подтверди, что его анкета в работе, и сошлись на занятость. Пример: "Здравствуйте! Да, помню вас. Ваша анкета у команды, просто сейчас действительно большая загруженность. Как только рекрутер освободится, он обязательно с вами свяжется. Спасибо за ожидание! 😉"
Не выдумывай информацию о себе (твоя компания, где ты работаешь и т.д.), если тебя спросят. Сосредоточься на процессе анкетирования и подогрева.
Твои ответы должны быть только текстом. Не используй markdown. Старайся делать свои реплики не слишком длинными (2-4 предложения).
Твоя текущая задача: {{current_task_instruction}}
Контекст обращения пользователя: {RECRUITMENT_CONTEXT}.
"""

SCENARIO = {
    "name": "HR Анкета с Gemini",
    "start_question_id": 1,
    "anketa_completed_status_id": 0, # ID статуса "анкета завершена"
    "greeting_instruction_template": "Кандидат только что написал (скорее всего, по поводу работы). Поприветствуй его очень дружелюбно и профессионально от имени {{bot_name}}. Поблагодари за интерес к компании/вакансии. Сообщи, что для начала хотел бы задать несколько вопросов, чтобы лучше понять его профиль и ускорить процесс. Затем сразу переходи к первому вопросу анкеты.",
    "warming_up_instruction_template": "Кандидат {{action_description}}. Твоя задача — поддержать его интерес и проявить заботу от имени {{bot_name}}. Поблагодари за терпение/сообщение. Сообщи, что его анкета/обращение находится в работе у команды рекрутеров. Подчеркни, что сейчас у команды высокая загрузка, но они обязательно свяжутся с ним в ближайшее возможное время, как только появится возможность. Заверь, что его кандидатура важна.",
    "questions": { # Темы вопросов для Gemini
        1: {"id": 1, "topic_for_gemini": "имя кандидата (как к нему обращаться)", "next_question_id": 2},
        2: {"id": 2, "topic_for_gemini": "возраст кандидата (полных лет)", "next_question_id": 3},
        3: {"id": 3, "topic_for_gemini": "город проживания кандидата", "next_question_id": 4},
        4: {"id": 4, "topic_for_gemini": "на какую должность или направление кандидат претендует (или его основной опыт/интерес)", "next_question_id": 0}, # 0 = anketa_completed_status_id
    }
}

# --- Функции для работы с состоянием пользователя в Redis ---
def get_redis_key_for_user_state(user_id: int) -> str:
    """Генерирует ключ для хранения состояния пользователя в Redis."""
    return f"agent:{TELEGRAM_SESSION_NAME}:user_state:{user_id}"

def save_user_state(user_id: int, state: dict):
    """Сохраняет состояние пользователя в Redis."""
    if not redis_client:
        logger.error(f"Redis клиент не инициализирован. Не могу сохранить состояние для user {user_id}.")
        return
    try:
        key = get_redis_key_for_user_state(user_id)
        # Обновляем last_activity перед сохранением
        state["last_activity_iso"] = datetime.now(timezone.utc).isoformat()
        redis_client.setex(key, USER_STATE_TTL_SECONDS, json.dumps(state))
        logger.debug(f"Состояние для user {user_id} сохранено в Redis (ключ: {key}, TTL: {USER_STATE_TTL_SECONDS}s).")
    except Exception as e:
        logger.error(f"Ошибка сохранения состояния user {user_id} в Redis: {e}", exc_info=True)

def get_user_state(user_id: int) -> dict:
    """Получает или инициализирует состояние диалога для пользователя из Redis."""
    if not redis_client:
        logger.error(f"Redis клиент не инициализирован. Возвращаю временное состояние по умолчанию для user {user_id}.")
        # Возвращаем временное состояние по умолчанию, чтобы бот мог попытаться продолжить работу,
        # но данные не будут сохраняться.
        default_state = {
            "current_question_id": SCENARIO["start_question_id"],
            "answers": {},
            "chat_history": [],
            "last_activity_iso": datetime.now(timezone.utc).isoformat() # Используем ISO формат
        }
        return default_state

    key = get_redis_key_for_user_state(user_id)
    try:
        state_json = redis_client.get(key)
        if state_json:
            state = json.loads(state_json)
            # Обновляем TTL при каждом доступе (продлеваем жизнь ключа)
            redis_client.expire(key, USER_STATE_TTL_SECONDS)
            logger.debug(f"Состояние для user {user_id} загружено из Redis (ключ: {key}). Продлен TTL.")
            # Обновляем last_activity_iso для текущей сессии в памяти, если нужно (но оно и так обновится при сохранении)
            state["last_activity_iso"] = datetime.now(timezone.utc).isoformat()
            return state
    except Exception as e:
        logger.error(f"Ошибка загрузки состояния user {user_id} из Redis (ключ: {key}): {e}", exc_info=True)

    # Если состояние не найдено или ошибка загрузки, создаем новое
    logger.info(f"Новый кандидат {user_id} или состояние не найдено в Redis. Инициализация HR сценария.")
    new_state = {
        "current_question_id": SCENARIO["start_question_id"],
        "answers": {},
        "chat_history": [],
        "last_activity_iso": datetime.now(timezone.utc).isoformat()
    }
    save_user_state(user_id, new_state) # Сохраняем начальное состояние
    return new_state


def add_to_chat_history(user_id: int, role: str, text: str):
    """Добавляет сообщение в историю чата для Gemini и сохраняет состояние."""
    state = get_user_state(user_id) # Получаем актуальное состояние
    if text and text.strip():
        state["chat_history"].append({"role": role, "parts": [{"text": text.strip()}]})
        max_history_items = 12
        if len(state["chat_history"]) > max_history_items:
            state["chat_history"] = state["chat_history"][-max_history_items:]
        save_user_state(user_id, state) # Сохраняем обновленное состояние
    else:
        logger.debug(f"Проигнорировано пустое сообщение для истории user {user_id} от {role}.")

def update_user_answer(user_id: int, question_id: int, answer: str):
    """Сохраняет ответ пользователя на конкретный вопрос и обновляет состояние в Redis."""
    state = get_user_state(user_id)
    logger.info(f"Ответ кандидата {user_id} на QID {question_id} сохранен: '{answer[:30]}...'")
    state["answers"][str(question_id)] = answer # Ключи в JSON должны быть строками, если это словарь answers
    save_user_state(user_id, state)

def advance_user_question(user_id: int, next_question_id: int):
    """Переводит пользователя на следующий шаг сценария и обновляет состояние в Redis."""
    state = get_user_state(user_id)
    logger.info(f"Кандидат {user_id}: переход с QID {state['current_question_id']} на QID {next_question_id}")
    state["current_question_id"] = next_question_id
    save_user_state(user_id, state)

# --- Функции Агента (Gemini и логика) ---
async def generate_gemini_response(user_id: int, current_task_instruction: str, user_message_text_for_history: str = None) -> str:
    """Генерирует ответ с помощью Gemini API."""
    global BOT_TELEGRAM_NAME
    if not BOT_TELEGRAM_NAME: BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}"

    state = get_user_state(user_id) # Получаем актуальное состояние
    if user_message_text_for_history:
        # Добавление в историю теперь происходит внутри add_to_chat_history, которая также сохраняет состояние
        add_to_chat_history(user_id, "user", user_message_text_for_history)
        state = get_user_state(user_id) # Перечитываем состояние, так как add_to_chat_history его обновила

    system_prompt_filled = IMPROVED_SYSTEM_PROMPT_TEMPLATE.format(
        bot_name=BOT_TELEGRAM_NAME,
        current_task_instruction=current_task_instruction
    )
    contents_for_gemini = [{"role": "user", "parts": [{"text": system_prompt_filled}]}]

    temp_combined_history = []
    last_role = "user"
    for entry in state.get("chat_history", []): # Используем .get для безопасности
        if entry["role"] == last_role and temp_combined_history:
            logger.warning(f"Нарушение чередования ролей для {user_id}. Пропуск проблемной записи.")
            continue
        temp_combined_history.append(entry)
        last_role = entry["role"]
    contents_for_gemini.extend(temp_combined_history)


    logger.debug(f"Запрос к Gemini для кандидата {user_id}. Задача: {current_task_instruction}. История: {len(temp_combined_history)} сообщ.")

    supported_harm_categories = [
        HarmCategory.HARM_CATEGORY_HARASSMENT,
        HarmCategory.HARM_CATEGORY_HATE_SPEECH,
        HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    ]

    safety_settings_for_request = {
        category: HarmBlockThreshold.BLOCK_NONE
        for category in supported_harm_categories
    }

    try:
        response = await gemini_model.generate_content_async(
            contents=contents_for_gemini,
            generation_config=genai.types.GenerationConfig(temperature=0.7, top_p=0.95),
            safety_settings=safety_settings_for_request
        )
        bot_text = "".join(part.text for part in response.candidates[0].content.parts) if response.candidates and response.candidates[0].content and response.candidates[0].content.parts else ""

        if not bot_text:
            block_reason_msg = "Причина неизвестна"
            if response.prompt_feedback and response.prompt_feedback.block_reason:
                block_reason_msg = response.prompt_feedback.block_reason.name
                logger.warning(f"Запрос к Gemini заблокирован для {user_id}: {block_reason_msg}")
                return f"(Ответ не сгенерирован из-за ограничений: {block_reason_msg.replace('_', ' ').title()})"
            else:
                logger.warning(f"Gemini вернул пустой текст для {user_id} без блокировки.")
                return "(Произошла заминка, повторите?)"

        add_to_chat_history(user_id, "model", bot_text) # Сохраняем ответ бота в историю (и в Redis)
        return bot_text.strip()

    except Exception as e:
        logger.error(f"Ошибка при запросе к Gemini API для {user_id}: {e}", exc_info=True)
        return f"Прошу прощения, возникла техническая проблема. ({BOT_TELEGRAM_NAME})"

async def process_user_message_logic(user_id: int, message_text: str) -> str:
    """Обрабатывает сообщение пользователя и определяет задачу для Gemini."""
    global BOT_TELEGRAM_NAME
    state = get_user_state(user_id) # Всегда получаем свежее состояние
    current_q_id = state.get("current_question_id", SCENARIO["start_question_id"]) # Безопасное получение
    instruction = ""

    if current_q_id == SCENARIO["anketa_completed_status_id"]:
        logger.info(f"Кандидат {user_id} (анкета завершена) пишет снова.")
        action_desc = "снова написал после завершения анкеты"
        instruction = SCENARIO["warming_up_instruction_template"].format(action_description=action_desc, bot_name=BOT_TELEGRAM_NAME)
    elif current_q_id in SCENARIO["questions"]:
        q_data = SCENARIO["questions"][current_q_id]
        update_user_answer(user_id, current_q_id, message_text.strip()) # Обновит и сохранит состояние
        next_q_id = q_data["next_question_id"]
        if next_q_id == SCENARIO["anketa_completed_status_id"]:
            logger.info(f"Кандидат {user_id} завершил анкету.")
            action_desc = "только что завершил(а) анкету"
            warming_instr = SCENARIO["warming_up_instruction_template"].format(action_description=action_desc, bot_name=BOT_TELEGRAM_NAME)
            instruction = f"Кандидат ответил на '{q_data['topic_for_gemini']}'. Отреагируй. Затем переходи к 'подогреву': \"{warming_instr}\"."
        else:
            next_q_data = SCENARIO["questions"][next_q_id]
            instruction = f"Кандидат ответил на '{q_data['topic_for_gemini']}'. Отреагируй. Затем задай вопрос о '{next_q_data['topic_for_gemini']}'."
        advance_user_question(user_id, next_q_id) # Обновит и сохранит состояние
    else:
        logger.error(f"Некорректный QID {current_q_id} для {user_id}. Сброс к началу.")
        state["current_question_id"] = SCENARIO["start_question_id"]
        state["answers"] = {}
        # state["chat_history"] = [] # Можно очистить историю или оставить для контекста
        save_user_state(user_id, state) # Сохраняем сброшенное состояние

        greeting_instr = SCENARIO["greeting_instruction_template"].format(bot_name=BOT_TELEGRAM_NAME)
        first_q_id = SCENARIO["start_question_id"]
        first_q_topic = SCENARIO["questions"][first_q_id]["topic_for_gemini"]
        instruction = f"{greeting_instr} Первый вопрос о '{first_q_topic}'. (Произошел сбой в сценарии, начнем с начала, пожалуйста)."

        # Не передаем user_message_text_for_history, так как это сброс
        bot_response = await generate_gemini_response(user_id, instruction, None)
        # Продвигаем на следующий после первого вопроса и сохраняем
        advance_user_question(user_id, SCENARIO["questions"][first_q_id]["next_question_id"])
        return bot_response

    # Для обычного хода диалога, user_message_text уже добавлен в историю в generate_gemini_response, если он был передан.
    # Здесь мы передаем message_text, чтобы он был добавлен в историю ПЕРЕД генерацией ответа на этот message_text
    return await generate_gemini_response(user_id, instruction, message_text)

# --- Основная логика работы Агента (запуск Telethon) ---
async def actual_agent_work():
    """Основная функция, запускающая и управляющая клиентом Telethon."""
    global BOT_TELEGRAM_NAME, client

    if not redis_client:
        logger.critical(f"Агент '{TELEGRAM_SESSION_NAME}' не может запуститься без подключения к Redis. Проверьте конфигурацию и доступность Redis.")
        return # Выход, если нет Redis

    logger.info(f"Запуск основной логики агента '{TELEGRAM_SESSION_NAME}'...")

    session_to_use = None
    if TELEGRAM_SESSION_STRING:
        logger.info("Используется строка сессии из ENV.")
        session_to_use = StringSession(TELEGRAM_SESSION_STRING)
    else:
        logger.critical(f"Критическая ошибка: TELEGRAM_SESSION_STRING не предоставлена для агента '{TELEGRAM_SESSION_NAME}'. Агент не может запуститься без строки сессии в Docker-окружении. Предоставьте строку сессии через переменные окружения.")
        return

    client = TelegramClient(session_to_use, TELEGRAM_API_ID, TELEGRAM_API_HASH)
    logger.info("Клиент Telethon инициализирован.")

    @client.on(events.NewMessage(incoming=True, forwards=False))
    async def handle_new_message(event):
        global BOT_TELEGRAM_NAME # Убедимся, что используется глобальная переменная

        # Проверка, что клиент активен и подключен
        if not client or not client.is_connected():
             logger.warning(f"Сообщение для '{TELEGRAM_SESSION_NAME}' получено, но клиент не активен или не подключен.")
             return

        if event.is_private and not event.message.out:
            user_id = event.sender_id
            message_text = event.text.strip() if event.text else ""
            logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Сообщение от кандидата {user_id}: '{message_text[:100]}...'")

            # Установка имени бота, если еще не задано
            if not BOT_TELEGRAM_NAME:
                try:
                     if await client.is_user_authorized():
                         me_user = await client.get_me()
                         if me_user: BOT_TELEGRAM_NAME = BOT_NAME_FROM_ENV or (me_user.first_name + (f" {me_user.last_name}" if me_user.last_name else ""))
                     if not BOT_TELEGRAM_NAME: BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}"
                     logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Имя бота динамически установлено/подтверждено: {BOT_TELEGRAM_NAME}")
                except Exception as e:
                    logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось получить/подтвердить имя бота: {e}")
                if not BOT_TELEGRAM_NAME: BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}"


            state = get_user_state(user_id) # Получаем состояние из Redis
            bot_reply_text = ""

            # Если история пуста (для этого пользователя) и это первый вопрос сценария
            if not state.get("chat_history") and state.get("current_question_id") == SCENARIO["start_question_id"]:
                greeting_instr = SCENARIO["greeting_instruction_template"].format(bot_name=BOT_TELEGRAM_NAME)
                first_q_id = SCENARIO["start_question_id"]
                first_q_topic = SCENARIO["questions"][first_q_id]["topic_for_gemini"]
                task = f"{greeting_instr} Первый вопрос о '{first_q_topic}'."
                # Не передаем user_message_text_for_history для первого приветственного сообщения
                bot_reply_text = await generate_gemini_response(user_id, task, None)
                advance_user_question(user_id, SCENARIO["questions"][first_q_id]["next_question_id"]) # Обновит и сохранит
            elif not message_text:
                task = f"Кандидат отправил нетекстовое или пустое сообщение. Скажи от имени {BOT_TELEGRAM_NAME}, что понимаешь только текстовые сообщения и попроси написать текстом."
                bot_reply_text = await generate_gemini_response(user_id, task, "[Кандидат отправил нетекстовое/пустое сообщение]")
            else:
                bot_reply_text = await process_user_message_logic(user_id, message_text)

            if bot_reply_text:
                await asyncio.sleep(random.uniform(1.0, 2.0))
                try:
                    await event.respond(bot_reply_text)
                    logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Ответ для {user_id} отправлен: '{bot_reply_text[:50]}...'")
                except (ChatWriteForbiddenError, UserIsBlockedError) as e:
                    logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Не удалось отправить сообщение пользователю {user_id} (заблокирован/запрещено писать): {e}")
                except FloodWaitError as e_flood:
                     wait_time = e_flood.seconds + random.uniform(1, 3)
                     logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': FloodWait при отправке сообщения пользователю {user_id}. Ожидание {wait_time:.1f} сек.")
                     await asyncio.sleep(wait_time)
                     try:
                         await event.respond(bot_reply_text)
                         logger.info(f"Агент '{TELEGRAM_SESSION_NAME}': Отправлен ответ пользователю {user_id} после FloodWait.")
                     except Exception as e_retry:
                         logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Ошибка повторной отправки сообщения пользователю {user_id} после FloodWait: {e_retry}")
                except Exception as e_respond:
                    logger.error(f"Агент '{TELEGRAM_SESSION_NAME}': Общая ошибка отправки сообщения пользователю {user_id}: {e_respond}", exc_info=True)
            else:
                logger.warning(f"Агент '{TELEGRAM_SESSION_NAME}': Сгенерирован пустой ответ для пользователя {user_id}, не отправляю.")

    is_authorized = False
    try:
        logger.info(f"Попытка подключения клиента '{TELEGRAM_SESSION_NAME}' с использованием предоставленной строки сессии...")
        await client.connect()

        if not client.is_connected():
            logger.critical(f"Не удалось подключиться к Telegram для агента '{TELEGRAM_SESSION_NAME}'. Проверьте сеть или валидность сессии.")
            return

        is_authorized = await client.is_user_authorized()

        if not is_authorized:
            logger.critical(f"Авторизация с использованием предоставленной строки сессии для '{TELEGRAM_SESSION_NAME}' НЕ УДАЛАСЬ. Строка сессии невалидна или отозвана. Агент будет остановлен. Пожалуйста, сгенерируйте новую строку сессии и обновите конфигурацию агента.")
            return

        # Устанавливаем или подтверждаем имя бота после успешной авторизации
        if not BOT_NAME_FROM_ENV: # Если имя не задано жестко
            try:
                me = await client.get_me()
                if me: BOT_TELEGRAM_NAME = me.first_name + (f" {me.last_name}" if me.last_name else "")
            except Exception as e:
                logger.warning(f"Не удалось получить имя из профиля Telegram для '{TELEGRAM_SESSION_NAME}': {e}")

        if not BOT_TELEGRAM_NAME: # Если все еще не установлено
            BOT_TELEGRAM_NAME = f"Ассистент {TELEGRAM_SESSION_NAME}" # Fallback

        logger.info(f"Агент '{BOT_TELEGRAM_NAME}' ({TELEGRAM_SESSION_NAME}) успешно авторизован и запущен. Слушает входящие сообщения. Redis: {REDIS_HOST}:{REDIS_PORT}")

        await client.run_until_disconnected()

    except (AuthKeyError, SessionExpiredError, UserDeactivatedError, UnauthorizedError) as e_auth:
        logger.critical(f"Критическая ошибка авторизации/сессии для '{TELEGRAM_SESSION_NAME}': {type(e_auth).__name__} - {e_auth}. Строка сессии невалидна, аккаунт удален/неактивен, или сессия истекла. Сгенерируйте новую строку сессии и перезапустите контейнер.", exc_info=True)
    except asyncio.CancelledError:
        logger.info(f"Работа агента '{TELEGRAM_SESSION_NAME}' отменена.")
    except ConnectionRefusedError: # Может быть выброшено и при подключении к Redis, если он не доступен при старте.
        logger.critical(f"Не удалось подключиться (ConnectionRefusedError) для '{TELEGRAM_SESSION_NAME}'. Проверьте сетевое соединение контейнера (к Telegram или Redis).")
    except redis.exceptions.ConnectionError as e_redis_main: # Ловим ошибки Redis здесь тоже
        logger.critical(f"Критическая ошибка соединения с Redis в основном потоке для агента '{TELEGRAM_SESSION_NAME}': {e_redis_main}", exc_info=True)
    except Exception as e:
        logger.critical(f"Критическая непредвиденная ошибка в `actual_agent_work` для '{TELEGRAM_SESSION_NAME}': {e}", exc_info=True)
    finally:
        if client and client.is_connected():
            logger.info(f"Отключение Telethon клиента '{TELEGRAM_SESSION_NAME}'...")
            try:
                await client.disconnect()
            except Exception as e_dc:
                logger.warning(f"Ошибка при отключении Telethon клиента '{TELEGRAM_SESSION_NAME}': {e_dc}")
        logger.info(f"Telethon клиент '{TELEGRAM_SESSION_NAME}' остановлен (или попытка остановки завершена).")

# --- Точка входа при запуске скрипта ---
if __name__ == '__main__':
    if BOT_NAME_FROM_ENV:
        BOT_TELEGRAM_NAME = BOT_NAME_FROM_ENV
    elif not BOT_TELEGRAM_NAME :
        BOT_TELEGRAM_NAME = f"HR Ассистент ({TELEGRAM_SESSION_NAME or 'Unknown'})"

    logger.info(f"Запуск экземпляра агента '{TELEGRAM_SESSION_NAME or 'Unknown'}' с предварительным именем '{BOT_TELEGRAM_NAME}'...")
    try:
        asyncio.run(actual_agent_work())
    except KeyboardInterrupt:
        logger.info(f"Получен сигнал Ctrl+C для агента '{TELEGRAM_SESSION_NAME or 'Unknown'}', инициирована остановка...")
    except Exception as e_main_run:
        logger.critical(f"Неперехваченная ошибка в основном блоке запуска (asyncio.run) для агента '{TELEGRAM_SESSION_NAME or 'Unknown'}': {e_main_run}", exc_info=True)
    finally:
        logger.info(f"Процесс агента '{TELEGRAM_SESSION_NAME or 'Unknown'}' завершен или находится в процессе завершения.")